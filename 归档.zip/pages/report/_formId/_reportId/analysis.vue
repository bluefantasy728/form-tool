<style lang="scss" scoped>
.time {
  width: 400px;
}
.title {
  font-size: 18px;
  line-height: 40px;
}
.map {
  width: 1400px;
  margin-left: -100px;
}

.block {
  width: 800px;
  margin: 30px auto;
}
.options {
  display: flex;
  .el-button {
    width: 180px;
    margin-right: 20px;
  }
  .active {
    background: #aaa;
  }
}
/deep/ {
  .el-button + .el-button {
    margin-left: 0;
  }
}
</style>

<template>
  <div class="page">
    <div class="container">
      <div class="clearfix">
        <div class="title fl">{{details.reportName}}</div>
        <el-date-picker
          class="fr ml100 time"
          v-model="dateValue"
          type="daterange"
          align="right"
          unlink-panels
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          @change="changeDate"
        ></el-date-picker>
      </div>
      <div class="mt30">
        <div class="options">
          <el-button
            :class="{active: select == `/report/${formId}/${reportId}/analysis`}"
            @click="changePage(`/report/${formId}/${reportId}/analysis`)"
          >数据总览</el-button>
          <!-- <el-button @click="changeFlag(true,'select')">完成数:{{downCount}}</el-button>
          <el-button @click="changeFlag(true,'select')">转化率:{{conversion}}</el-button>-->
          <el-button
            :class="{active: select == `/report/${formId}/${reportId}/analysis/result`}"
            @click="changePage(`/report/${formId}/${reportId}/analysis/result`)"
          >结果分析</el-button>
        </div>
        <nuxt-child></nuxt-child>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  async asyncData({ app, store }) {
    let reportId = app.context.params.reportId;
    let formId = app.context.params.formId;
    let endDate = new Date().getTime();
    let startDate = endDate - 3600 * 1000 * 24 * 6;
    store.commit('report/dateValue', [startDate, endDate]);
    let res = await app.$axios.$get(`/report/${reportId}`);
    return {
      details: res,
      dateValue: [startDate, endDate],
      reportId,
      formId,
    };
  },
  components: {},
  beforeRouteEnter(to, from, next) {
    next();
  },
  computed: {},
  data() {
    return {
      select: '',
    };
  },
  watch: {
    '$route.path'() {
      this.select = this.$route.path;
    },
  },
  mounted() {
    this.select = this.$route.path;
  },
  methods: {
    showShadow(str) {
      this.name = str;
      this.show = true;
    },
    hideShadow() {
      this.show = false;
    },
    changePage(path) {
      if (path == this.$route.path) {
        return;
      }
      this.select = path;
      this.$router.push({ path });
    },
    changeDate(value) {
      this.$store.commit('report/dateValue', [
        this.$moment(value[0]).valueOf(),
        this.$moment(value[1]).valueOf(),
      ]);
    },
  },
};
</script>

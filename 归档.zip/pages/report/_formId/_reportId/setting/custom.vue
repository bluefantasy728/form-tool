<style lang="scss" scoped>
.tab {
  margin-left: 50px;
  width: 750px;
}
.line {
  width: 300px;
  .el-input {
    margin: 20px 0;
  }
}
</style>
<template>
  <div class="tab">
    <el-table :data="details.reportConditionParam.conditionParamList" style="width: 100%">
      <el-table-column label="字段名" width="180">
        <template slot-scope="scope">
          <el-select
            size="small"
            v-model="scope.row.conditionColumnUUID"
            placeholder="请选择"
            @change="change($event, scope.$index)"
          >
            <el-option
              v-for="(item,index) in column"
              :key="item.uuid"
              :label="item.title + ' '"
              :value="item.uuid"
            ></el-option>
          </el-select>
        </template>
      </el-table-column>
      <el-table-column label="操作符" width="180">
        <template slot-scope="scope">
          <el-select size="small" v-model="scope.row.conditionOperate" placeholder="请选择">
            <el-option v-for="(value,key) in operate" :key="value" :label="key" :value="value"></el-option>
          </el-select>
        </template>
      </el-table-column>
      <el-table-column label="比较值" width="240">
        <template slot-scope="scope">
          <el-time-picker
            v-if="scope.row.com == 'ztime'"
            size="small"
            v-model="scope.row.conditionCompareValue"
          ></el-time-picker>
          <el-date-picker
            v-else-if="scope.row.com == 'zdate'"
            type="date"
            size="small"
            v-model="scope.row.conditionCompareValue"
          ></el-date-picker>
          <el-date-picker
            v-else-if="scope.row.com == 'zdateTime'"
            type="datetime"
            size="small"
            v-model="scope.row.conditionCompareValue"
          ></el-date-picker>
          <el-select
            size="small"
            v-else-if="scope.row.com == 'zradio' || scope.row.com == 'zselect' || scope.row.com == 'zcheckbox'"
            v-model="scope.row.conditionCompareValue"
          >
            <el-option
              v-for="(item,index) in scope.row.options"
              :key="index"
              :label="item"
              :value="item"
            ></el-option>
          </el-select>
          <el-input v-else size="small" v-model="scope.row.conditionCompareValue"></el-input>
        </template>
      </el-table-column>
      <el-table-column label="" width="180">
        <template slot-scope="scope">
          <el-button size="small" icon="el-icon-plus" @click="push(scope.$index)"></el-button>
          <el-button size="small" icon="el-icon-minus" @click="del(scope.$index)"></el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="clearfix mt30">
      <div class="fl">
        <el-radio v-model="details.reportConditionParam.must" :label="true">全部满足</el-radio>
        <el-radio v-model="details.reportConditionParam.must" :label="false">一项满足</el-radio>
      </div>
      <el-button class="fr" @click="putData">保存</el-button>
    </div>
  </div>
</template>

<script>
const obj = {
  conditionColumn: '',
  conditionColumnUUID: '',
  conditionCompareValue: '',
  conditionOperate: '',
  com: '',
  options: [],
};
import setting from '@/mixin/setting';
export default {
  async asyncData({ app }) {
    let reportId = app.context.params.reportId;
    let formId = app.context.params.formId;
    let res = await app.$axios.$get(`/report/column/${formId}`);
    let res2 = await app.$axios.$get(`/report/operate`);
    let res3 = await app.$axios.$get(`/report/${reportId}`);
    if (!res3.reportConditionParam.conditionParamList.length) {
      res3.reportConditionParam.conditionParamList.push(Object.assign({}, obj));
    }
    for (
      let i = 0;
      i < res3.reportConditionParam.conditionParamList.length;
      i++
    ) {
      if (
        res3.reportConditionParam.conditionParamList[i].com == 'zradio' ||
        res3.reportConditionParam.conditionParamList[i].com == 'zselect' ||
        res3.reportConditionParam.conditionParamList[i].com == 'zcheckbox'
      ) {
        res3.reportConditionParam.conditionParamList[
          i
        ].options = await app.$axios.$get(
          `/form/${formId}/config/${
            res3.reportConditionParam.conditionParamList[i].conditionColumnUUID
          }`,
        );
      }
    }
    return {
      column: res,
      operate: res2,
      details: res3,
      reportId,
      formId,
    };
  },
  mixins: [setting],
  components: {},
  computed: {},
  data() {
    return {
      options: [],
    };
  },
  mounted() {
    console.log(this.column, this.details);
  },
  methods: {
    async change(val, index) {
      console.log(val, index);
      this.details.reportConditionParam.conditionParamList[
        index
      ].conditionCompareValue = '';
      let ss = this.column.filter(v => {
        return v.uuid == val;
      });
      this.details.reportConditionParam.conditionParamList[
        index
      ].conditionColumn = ss[0].title;
      this.details.reportConditionParam.conditionParamList[index].com =
        ss[0].com;
      if (
        ss[0].com == 'zradio' ||
        ss[0].com == 'zselect' ||
        ss[0].com == 'zcheckbox'
      ) {
        let res = await this.$axios.$get(
          `/form/${this.formId}/config/${ss[0].uuid}`,
        );
        this.details.reportConditionParam.conditionParamList[
          index
        ].options = res;
      }
    },
    push(index) {
      this.details.reportConditionParam.conditionParamList.splice(
        index + 1,
        0,
        Object.assign({}, obj),
      );
    },
    del(index) {
      this.details.reportConditionParam.conditionParamList.splice(index, 1);
      if (!this.details.reportConditionParam.conditionParamList.length) {
        this.details.reportConditionParam.conditionParamList.push(obj);
      }
    },
  },
};
</script>

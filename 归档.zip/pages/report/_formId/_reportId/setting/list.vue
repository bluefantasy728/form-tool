<style lang="scss" scoped>
.tab {
  margin-left: 50px;
}
.line {
  width: 300px;
  .el-input {
    margin: 20px 0;
  }
}
/deep/ .el-checkbox__input {
  top: -12px;
}
</style>
<template>
  <div class="tab">
    <el-table :data="details.reportColumnParam.columnParamList" style="width: 100%">
      <el-table-column prop="columnName" label="字段名" width="180"></el-table-column>
      <el-table-column label="别名" width="180">
        <template slot-scope="scope">
          <el-input v-model="scope.row.columnAlias"></el-input>
        </template>
      </el-table-column>
      <el-table-column label="是否隐藏">
        <template slot-scope="scope">
          <el-checkbox v-model="scope.row.hidden"></el-checkbox>
        </template>
      </el-table-column>
    </el-table>
    <div class="clearfix mt30">
      <el-button class="fr" @click="putData">保存</el-button>
    </div>
  </div>
</template>

<script>
import setting from '@/mixin/setting';
export default {
  async asyncData({ app }) {
    let reportId = app.context.params.reportId;
    let res = await app.$axios.$get(`/report/${reportId}`);
    return {
      details: res,
      reportId,
    };
  },
  mixins: [setting],
  components: {},
  computed: {},
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>

<style lang="scss" scoped>
.tab {
  margin-left: 50px;
}
.line {
  width: 300px;
  .el-input {
    margin: 20px 0;
  }
}
</style>

<template>
  <div class="tab">
    <div class="line">
      <div>报表名称:</div>
      <el-input v-model="details.reportName"></el-input>
    </div>
    <div class="line">
      <div>描述:</div>
      <el-input v-model="details.reportDescription"></el-input>
    </div>
    <el-button class="fr" @click="putData">保存</el-button>
  </div>
</template>

<script>
import setting from '@/mixin/setting';
export default {
  async asyncData({ app }) {
    let reportId = app.context.params.reportId;
    let res = await app.$axios.$get(`/report/${reportId}`);
    return {
      details: res,
      reportId,
    };
  },
  mixins: [setting],
  components: {},
  computed: {},
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>

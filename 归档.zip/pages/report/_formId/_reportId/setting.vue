<style lang="scss" scoped>
.container {
  width: 1000px;
  padding-top: 100px;
  margin: 0 auto;
  overflow: hidden;
  .left {
    float: left;
    width: 200px;
    ul {
      height: 200px;
      display: flex;
      justify-content: space-between;
      flex-flow: column;
      li {
        cursor: pointer;
        font-size: 18px;
        line-height: 40px;
        height: 40px;
        width: 100px;
        position: relative;
        transition: all linear 0.2s;
        left: 0;
        &.select {
          border-bottom: 1px solid #000;
          left: 20px;
          &::after {
            content: '';
            width: 0;
            height: 0;
            border-left: 10px solid #000;
            border-top: 5px solid transparent;
            border-bottom: 5px solid transparent;
            position: absolute;
            left: -20px;
            top: 50%;
            transform: translateY(-50%);
          }
        }
        > .router {
          width: 100%;
          height: 100%;
          display: inline-block;
        }
      }
    }
  }
  .right {
    float: left;
  }
}
</style>

<template>
  <div class="page">
    <div class="container">
      <div class="left">
        <ul>
          <li
            :class="{select: index == `/report/${formId}/${reportId}/setting`}"
            @click="changeSelect(`/report/${formId}/${reportId}/setting`)"
          >常规设置</li>
          <li
            :class="{select: index == `/report/${formId}/${reportId}/setting/custom`}"
            @click="changeSelect(`/report/${formId}/${reportId}/setting/custom`)"
          >自定义条件</li>
          <li
            :class="{select: index == `/report/${formId}/${reportId}/setting/list`}"
            @click="changeSelect(`/report/${formId}/${reportId}/setting/list`)"
          >列内容设置</li>
        </ul>
      </div>
      <nuxt-child class="right"/>
    </div>
  </div>
</template>

<script>
export default {
  asyncData({ app }) {
    let formId = app.context.params.formId;
    let reportId = app.context.params.reportId;
    return {
      formId,
      reportId,
    };
  },
  components: {},
  computed: {},
  data() {
    return {
      index: 0,
      id: '',
    };
  },
  created() {
    this.index = this.$route.path;
    this.id = this.$route.params.reportId;
  },
  mounted() {},
  methods: {
    changeSelect(index) {
      this.index = index;
      this.$router.push(index);
    },
  },
};
</script>

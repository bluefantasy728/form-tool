<style lang="scss" scoped>
.time {
  line-height: 40px;
}

.title {
  font-size: 18px;
  line-height: 40px;
}
.card {
  position: relative;
  margin-top: 20px;
  .menu {
    position: absolute;
    top: 20px;
    right: 20px;
    .btn {
      width: 32px;
      height: 32px;
      font-size: 32px;
      border: 1px solid #eee;
    }
    .menu2 {
      position: absolute;
      top: 32px;
      right: 0;
      width: 32px;
    }
  }
}
.head {
  text-align: center;
  line-height: 40px;
  height: 40px;
  font-size: 16px;
  margin: 0 40px;
  > div {
    border: 1px solid #eee;
  }
  .option {
    width: 20%;
  }
  .result {
    width: 75%;
  }
}
.line {
  margin: 10px 60px;
  .choose {
    width: 80%;
    border-bottom: 1px solid #eee;
    padding: 5px 10px;
  }
  .btn {
    border: 1px solid #eee;
    padding: 5px 10px;
  }
}
.echarts {
  width: 100%;
  height: 500px;
}
.pie {
  width: 50%;
  height: 300px;
  float: left;
}
</style>

<template>
  <div>
    <div class="block">
      <div class="clearfix mt30">
        <el-select size="small" v-model="select" placeholder="请选择" @change="change">
          <el-option
            v-for="(item,index) in details"
            :key="item.uuid"
            :label="item.title"
            :value="index"
          ></el-option>
        </el-select>
        <el-button class="fr" size="small" @click="exportReport" :disabled="!details.length">报告导出</el-button>
        <el-button class="fr mr30" size="small" @click="getOpt">添加纬度</el-button>
      </div>
      <el-card class="card imageWrap">
        <div v-if="question.passCount != question.downCount">
          <div class="title">{{question.title}}</div>
          <div>完成数:{{question.downCount}} 跳过数:{{question.passCount}}</div>
          <div v-if="question.com == 'ztextarea' || question.com == 'zinput'">
            <no-ssr>
              <wchart @finished="onFinish" :xdata="xData"></wchart>
            </no-ssr>
          </div>
          <div v-else>
            <no-ssr placeholder="Loading...">
              <v-chart ref="barChart" @finished="onFinish" :options="barOption"></v-chart>
            </no-ssr>
          </div>
          <div class="menu clearfix" v-show="!flag.show">
            <!-- <el-select
              class="fr"
              v-if="question.com != 'ztextarea'"
              size="small"
              v-model="select1"
              placeholder="请选择"
              @change="changeChart"
            >
              <el-option
                v-for="(item,index) in ['横向柱状图','纵向柱状图']"
                :key="index"
                :label="item"
                :value="index"
                :disabled="select1 == index"
              ></el-option>
            </el-select>-->
          </div>
          <div
            v-if="question.com != 'ztextarea' && question.com != 'zinput' && question.com != 'zsort'"
          >
            <div class="head clearfix">
              <div class="option fl">选项名称</div>
              <div class="result fr">结果</div>
            </div>
            <div>
              <ul>
                <li class="line clearfix" v-for="(value,key) in question.data" :key="key">
                  <div class="fl choose clearfix">
                    <span>{{key}}</span>
                    <span class="fr">{{value}}</span>
                    <span
                      class="fr mr100"
                    >{{question.downCount ? parseFloat((value/question.downCount * 100).toPrecision(12)).toFixed(2) : 0}}%</span>
                  </div>
                  <div class="fr btn pointer" v-if="1" @click="openCharts(key)">more</div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <nodata v-else class="mb80 center"></nodata>
      </el-card>
      <div class="clearfix mt30">
        <el-button @click="changeSelect('l')" class="fl" :disabled="this.select == 0">上一题</el-button>
        <el-button
          @click="changeSelect('n')"
          class="fr"
          :disabled="this.select + 1 == this.details.length"
        >下一题</el-button>
      </div>
    </div>
    <el-dialog :visible.sync="flag.dialogVisible" width="70%" :show-close="false">
      <no-ssr placeholder="Loading...">
        <v-chart class="pie" :options="pieOption"></v-chart>
        <v-chart class="pie" :options="pieOption2"></v-chart>
      </no-ssr>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="flag.dialogVisible = false">关闭</el-button>
      </span>
    </el-dialog>
    <el-dialog :visible.sync="flag.dialogVisible2" width="70%" :show-close="false">
      <el-table :data="conditionParamList" style="width: 100%">
        <el-table-column label="字段名" width="230">
          <template slot-scope="scope">
            <el-select
              size="small"
              v-model="scope.row.conditionColumnUUID"
              placeholder="请选择"
              @change="change2($event, scope.$index)"
            >
              <el-option
                v-for="(item,index) in column"
                :key="item.uuid"
                :label="item.title + ' '"
                :value="item.uuid"
              ></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="操作符" width="230">
          <template slot-scope="scope">
            <el-select size="small" v-model="scope.row.conditionOperate" placeholder="请选择">
              <el-option v-for="(value,key) in operate" :key="value" :label="key" :value="value"></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="比较值" width="auto">
          <template slot-scope="scope">
            <el-select
              size="small"
              v-if="scope.row.com == 'zradio' || scope.row.com == 'zselect' || scope.row.com == 'zcheckbox'"
              v-model="scope.row.conditionCompareValue"
            >
              <el-option v-for="(item,index) in option" :key="index" :label="item" :value="item"></el-option>
            </el-select>
            <el-input v-else size="small" v-model="scope.row.conditionCompareValue"></el-input>
          </template>
        </el-table-column>
      </el-table>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="flag.dialogVisible2 = false">取消</el-button>
        <el-button type="primary" @click="clear">清除过滤条件</el-button>
        <el-button type="primary" @click="screen">确定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      :visible.sync="flag.show"
      width="200px"
      top="30vh"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
    >
      <el-progress type="circle" :width="150" :percentage="schedule"></el-progress>
    </el-dialog>
  </div>
</template>

<script>
import nodata from '@/components/ui/noData';
import 'echarts/lib/chart/bar';
import 'echarts/lib/chart/pie';
import 'echarts/lib/component/tooltip';
import html2canvas from 'html2canvas';
import pdfmake from 'pdfmake';
import { nextTick } from 'q';
import { setTimeout } from 'timers';
const labelOption = {
  normal: {
    show: true,
    position: 'insideBottom',
    distance: 15,
    align: 'left',
    verticalAlign: 'middle',
    rotate: 90,
    formatter: '{c}  {name|{a}}',
    fontSize: 16,
    rich: {
      name: {
        textBorderColor: '#fff',
      },
    },
  },
};
const bar = {
  type: 'bar',
  barGap: 0,
  barMaxWidth: 60,
  data: [],
};
const bar2 = {
  type: 'bar',
  barGap: 0,
  barMaxWidth: 60,
  label: labelOption,
  data: [],
};
const barOption = {
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow',
    },
  },
  xAxis: {
    type: 'category',
    data: [],
  },
  yAxis: {
    type: 'value',
  },
  series: [
    {
      type: 'bar',
      barMaxWidth: 60,
      data: [],
    },
  ],
};
const pieOption = {
  title: {
    text: '地域统计',
    x: 'center',
  },
  tooltip: {
    trigger: 'item',
    formatter: '{a} <br/>{b} : {c} ({d}%)',
  },
  series: [
    {
      name: '访问来源',
      type: 'pie',
      radius: '55%',
      center: ['50%', '50%'],
      data: [],
      itemStyle: {
        emphasis: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)',
        },
      },
    },
  ],
};
const pieOption2 = {
  title: {
    text: '操作系统统计',
    x: 'center',
  },
  tooltip: {
    trigger: 'item',
    formatter: '{a} <br/>{b} : {c} ({d}%)',
  },
  series: [
    {
      name: '访问来源',
      type: 'pie',
      radius: '55%',
      center: ['50%', '50%'],
      data: [],
      itemStyle: {
        emphasis: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)',
        },
      },
    },
  ],
};
export default {
  async asyncData({ app, store }) {
    let reportId = app.context.params.reportId;
    let formId = app.context.params.formId;
    let res = await app.$axios.$get(`/report/analysis`, {
      params: {
        reportId,
        startDate: store.state.report.dateValue[0],
        endDate: store.state.report.dateValue[1],
      },
    });
    let res2;
    let xData = [],
      yData = [];
    if (res.length) {
      res2 = await app.$axios.$post(
        `/report/quession/${res[0] ? res[0].uuid : ''}/${reportId}/analysis`,
        {
          startDate: store.state.report.dateValue[0],
          endDate: store.state.report.dateValue[1],
        },
      );
      if (res2 && res2.data) {
        if (res2.com == 'ztextarea' || res2.com == 'zinput') {
          xData = res2.data.map(v => {
            return {
              name: v.word,
              value: v.count,
            };
          });
        } else if (res2.com == 'zsort') {
          yData = res2.data.xAxis;
          for (let i in res2.data.series) {
            let obj = Object.assign({}, bar2);
            obj.name = i;
            obj.data = res2.data.series[i];
            xData.push(obj);
          }
        } else {
          for (let i in res2.data) {
            xData.push(res2.data[i]);
            yData.push(i);
          }
        }
      }
      return {
        details: res,
        question: res2,
        reportId,
        formId,
        xData,
        yData,
        select: 0,
        select1: 0,
      };
    } else {
      return {
        details: res,
        question: {},
        reportId,
        formId,
        xData,
        yData,
        select: '',
      };
    }
  },
  watch: {
    dateValue() {
      this.getData();
    },
  },
  components: {
    nodata,
  },
  computed: {
    dateValue() {
      return this.$store.state.report.dateValue;
    },
  },
  data() {
    return {
      schedule: 0,
      barOption,
      pieOption,
      pieOption2,
      option: [],
      column: [],
      operate: [],
      flag: {
        show: false,
        show2: false,
        dialogVisible: false,
        dialogVisible2: false,
        select: false,
      },
      print: false, //打印时的计时
      conditionParamList: [
        {
          conditionColumn: '',
          conditionColumnUUID: '',
          conditionCompareValue: '',
          conditionOperate: '',
        },
      ],
    };
  },
  methods: {
    getDv() {
      this.barOption.xAxis.data = this.yData;
      if (this.question.com != 'zsort') {
        let obj = Object.assign({}, bar);
        obj.data = this.xData;
        this.barOption.series = [obj];
      } else {
        this.barOption.series = this.xData;
      }
      if (this.$refs.barChart) {
        this.$refs.barChart.mergeOptions(this.barOption, true);
      }
    },
    async screen() {
      await this.getData();
      this.flag.dialogVisible2 = false;
    },
    clear() {
      this.conditionParamList = [
        {
          conditionColumn: '',
          conditionColumnUUID: '',
          conditionCompareValue: '',
          conditionOperate: '',
        },
      ];
    },
    onFinish() {
      this.print = true;
    },
    // changeChart(val) {
    //   if (this.select1 == 0) {
    //     let Axis = Object.assign({}, this.barOption.yAxis);
    //     this.barOption.yAxis = Object.assign({}, this.barOption.xAxis);
    //     this.barOption.xAxis = Axis;
    //   } else {
    //     let Axis = Object.assign({}, this.barOption.yAxis);
    //     this.barOption.yAxis = Object.assign({}, this.barOption.xAxis);
    //     this.barOption.xAxis = Axis;
    //   }
    // },
    async getOpt() {
      if (!this.operate.length) {
        let res = await this.$axios.$get(`/report/column/${this.formId}`);
        let res2 = await this.$axios.$get(`/report/operate`);
        this.column = res;
        this.operate = res2;
      }
      this.flag.dialogVisible2 = true;
    },
    showShadow(str) {
      this.name = str;
      this.show = true;
    },
    hideShadow() {
      this.show = false;
    },
    changeSelect(str) {
      if (str == 'l') {
        this.select -= 1;
      } else {
        this.select += 1;
      }
      this.getData(this.details[this.select].uuid);
    },
    change(val) {
      this.getData(this.details[val].uuid);
    },
    async change2(val, index) {
      this.conditionParamList[0].conditionCompareValue = '';
      let ss = this.column.filter(v => {
        return v.uuid == val;
      });
      this.conditionParamList[0].conditionColumn = ss[0].title;
      this.conditionParamList[0].com = ss[0].com;
      if (
        ss[0].com == 'zradio' ||
        ss[0].com == 'zselect' ||
        ss[0].com == 'zcheckbox'
      ) {
        let res = await this.$axios.$get(
          `/form/${this.formId}/config/${ss[0].uuid}`,
        );
        this.option = res;
      }
    },
    async getData(val) {
      try {
        let res = await this.$axios.$post(
          `/report/quession/${val ? val : this.question.uuid}/${
            this.reportId
          }/analysis`,
          {
            conditionParamList: this.conditionParamList,
            startDate: this.dateValue[0],
            endDate: this.dateValue[1],
          },
        );
        let xData = [],
          yData = [];
        if (res.data) {
          if (res.com == 'ztextarea' || res.com == 'zinput') {
            xData = res.data.map(v => {
              return {
                name: v.word,
                value: v.count,
              };
            });
          } else if (res.com == 'zsort') {
            yData = res.data.xAxis;
            for (let i in res.data.series) {
              let obj = Object.assign({}, bar2);
              obj.name = i;
              obj.data = res.data.series[i];
              xData.push(obj);
            }
          } else {
            for (let i in res.data) {
              xData.push(res.data[i]);
              yData.push(i);
            }
          }
        }
        this.xData = xData;
        this.yData = yData;
        this.question = res;
        this.getDv();
      } catch (err) {}
    },
    async openCharts(key) {
      try {
        let res = await this.$axios.$get(
          `/report/quession/${this.question.uuid}/areaAndos`,
          {
            params: {
              reportId: this.reportId,
              com: this.question.com,
              answer: key,
              startDate: this.dateValue[0],
              endDate: this.dateValue[1],
            },
          },
        );
        res.area = res.area.map(v => {
          return {
            name: v.key,
            value: v.value,
          };
        });
        res.os = res.os.map(v => {
          return {
            name: v.key,
            value: v.value,
          };
        });
        this.pieOption.series[0].data = res.area;
        this.pieOption2.series[0].data = res.os;
        this.flag.dialogVisible = true;
      } catch (err) {}
    },
    getPrint() {
      let _this = this;
      return new Promise((resolve, reject) => {
        setInterval(() => {
          if (_this.print) {
            resolve();
          }
        }, 200);
      });
    },
    async exportReport() {
      this.flag.show = true;
      this.print = false;
      var docDefinition = {
        pageSize: 'A4',
        pageMargins: [5, 0, 5, 0],
        content: [],
      };
      for (let i = 0; i < this.details.length; i++) {
        this.schedule = Number(((i / this.details.length) * 100).toFixed(2));
        await this.getData(this.details[i].uuid);
        if (this.question.passCount != this.question.downCount) {
          await this.getPrint();
        }
        this.print = false;
        if (this.question.passCount != this.question.downCount) {
          let canvas = await html2canvas(
            document.getElementsByClassName('imageWrap')[0],
            {
              backgroundColor: null,
            },
          );
          let dataURL = canvas.toDataURL('image/png', 1);
          docDefinition.content.push({
            image: dataURL,
            width: 585,
            margin: [0, 0, 0, 20],
          });
        }
      }
      pdfmake.createPdf(docDefinition).download();
      this.flag.show = false;
      this.getData(this.details[this.select].uuid);
    },
  },
  mounted() {
    this.getDv();
  },
};
</script>

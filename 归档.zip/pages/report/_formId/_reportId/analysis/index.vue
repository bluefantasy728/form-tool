<style lang="scss" scoped>
.options {
  display: flex;
  .el-button {
    width: 180px;
  }
  .active {
    background: #aaa;
  }
}
.line {
  margin: 10px 60px;
  .choose {
    width: 80%;
    border-bottom: 1px solid #eee;
    padding: 5px 10px;
  }
  .btn {
    border: 1px solid #eee;
    padding: 5px 10px;
  }
}
.part {
  width: 50%;
  float: left;
  height: 40px;
  .left {
    width: 60%;
    height: 40px;
    .schedule {
      margin-top: 5px;
      height: 10px;
      background: #cbdfa3;
    }
  }
  .right {
    float: right;
    margin-right: 40px;
    line-height: 40px;
  }
}
.options {
  display: flex;
  .el-button {
    width: 180px;
    margin-right: 20px;
  }
  .active {
    background: #aaa;
  }
}
.echarts {
  width: 100%;
  height: 500px;
}
</style>

<template>
  <div>
    <div class="mt20">
      <span class="mr10">访问总量:{{details.joinCount}}</span>
      <span class="mr10">完成数:{{details.downCount}}</span>
      <span>
        转化率:{{details.joinCount
        ? parseFloat(
        ((details.downCount / details.joinCount) * 100).toPrecision(12)).toFixed(2) + '%'
        : 0}}
      </span>
    </div>
    <div>
      <no-ssr placeholder="Loading...">
        <v-chart :options="barOption"></v-chart>
      </no-ssr>
    </div>
    <div class="options">
      <el-button :class="{active: flag}" @click="changeFlag(true)">地理位置</el-button>
      <el-button :class="{active: !flag}" @click="changeFlag(false)">操作系统</el-button>
    </div>
    <div v-show="flag" style="overflow:hidden">
      <no-ssr placeholder="Loading...">
        <v-chart :options="mapOption"></v-chart>
      </no-ssr>
    </div>
    <div v-show="!flag" class="clearfix mt20">
      <div class="part mt20" v-for="(item,index) in areaAndos.os" :key="index">
        <div class="fl left">
          <div>{{item.key}}({{parseFloat((item.value/areaAndos.sum * 100).toPrecision(12)).toFixed(2)+"%"}})</div>
          <div
            class="schedule"
            :style="`width:${parseFloat((item.value/areaAndos.sum * 100).toPrecision(12)).toFixed(2)}%;`"
          ></div>
        </div>
        <div class="fl right">{{item.value}}</div>
      </div>
    </div>
  </div>
</template>

<script>
import 'echarts/lib/chart/bar';
import 'echarts/lib/chart/map';
import 'echarts/map/js/china';
const barOption = {
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow',
      label: {
        show: true,
      },
    },
  },
  legend: {
    data: ['top2000 唱片'],
  },
  grid: {
    top: '12%',
    left: '1%',
    right: '10%',
    containLabel: true,
  },
  xAxis: [
    {
      type: 'category',
      data: [],
    },
  ],
  yAxis: [
    {
      type: 'value',
      name: '访问总量',
    },
  ],
  dataZoom: [
    {
      show: true,
      start: 0,
      end: 100,
    },
  ],
  series: [
    // {
    //   type: 'bar',
    //   itemStyle: {
    //     normal: { color: 'rgba(0,0,0,0.05)' },
    //   },
    //   barGap: '-100%',
    //   barCategoryGap: '40%',
    //   data: top.max,
    //   animation: false,
    // },
    {
      name: '访问量',
      type: 'bar',
      data: [],
    },
  ],
};
const mapOption = {
  tooltip: {
    trigger: 'item',
  },
  visualMap: {
    min: 0,
    max: 1000,
    left: 'left',
    top: 'bottom',
    text: ['高', '低'], // 文本，默认为数值文本
  },
  series: [
    {
      name: '人数',
      type: 'map',
      mapType: 'china',
      roam: false,
      label: {
        normal: {
          show: true,
        },
      },
      data: [],
    },
  ],
};
export default {
  async asyncData({ app, store }) {
    let reportId = app.context.params.reportId;
    let res = await app.$axios.$post(`/report/${reportId}/getUniqueEventList`, {
      endTime: store.state.report.dateValue[1],
      startTime: store.state.report.dateValue[0],
      timeType: 'hour',
    });
    let areaAndos = await app.$axios.$get(`/report/quession/areaAndos`, {
      params: {
        reportId: reportId,
        startDate: store.state.report.dateValue[0],
        endDate: store.state.report.dateValue[1],
      },
    });
    let sum = 0;
    for (let i = 0; i < areaAndos.os.length; i++) {
      sum += areaAndos.os[i].value;
    }
    let xData = [],
      yData = [];
    for (var i in res.uniqueEvents) {
      xData.push(res.uniqueEvents[i].timePeriod);
      yData.push(res.uniqueEvents[i].uniqueEvents);
    }
    areaAndos.area = areaAndos.area.map((v, k) => {
      return {
        name: v.key,
        value: v.value,
      };
    });
    areaAndos.sum = sum;
    store.commit('report/count', {
      visitsCount: res.joinCount,
      downCount: res.downCount,
    });
    return {
      details: res,
      xData,
      yData,
      areaAndos,
      reportId,
    };
  },
  watch: {
    dateValue() {
      this.getData();
    },
  },
  components: {},
  computed: {
    dateValue() {
      return this.$store.state.report.dateValue;
    },
  },
  data() {
    return {
      barOption,
      mapOption,
      flag: true,
    };
  },
  methods: {
    changeFlag(flag) {
      this.flag = flag;
    },
    getMap() {
      this.mapOption.series[0].data = this.areaAndos.area;
    },
    getBar() {
      this.barOption.xAxis[0].data = this.xData;
      this.barOption.series[0].data = this.yData;
    },
    async getData() {
      let res = await this.$axios.$post(
        `/report/${this.reportId}/getUniqueEventList`,
        {
          endTime: this.dateValue[1],
          startTime: this.dateValue[0],
          timeType: 'hour',
        },
      );
      let areaAndos = await this.$axios.$get(`/report/quession/areaAndos`, {
        params: {
          reportId: this.reportId,
          startDate: this.dateValue[0],
          endDate: this.dateValue[1],
        },
      });
      let sum = 0;
      for (let i = 0; i < areaAndos.os.length; i++) {
        sum += areaAndos.os[i].value;
      }
      let xData = [],
        yData = [];
      for (var i in res.uniqueEvents) {
        xData.push(res.uniqueEvents[i].timePeriod);
        yData.push(res.uniqueEvents[i].uniqueEvents);
      }
      areaAndos.area = areaAndos.area.map((v, k) => {
        return {
          name: v.key,
          value: v.value,
        };
      });
      areaAndos.sum = sum;
      this.xData = xData;
      this.yData = yData;
      this.areaAndos = areaAndos;
      this.getMap();
      this.getBar();
    },
  },
  mounted() {
    console.log(this.details);
    this.getMap();
    this.getBar();
  },
};
</script>

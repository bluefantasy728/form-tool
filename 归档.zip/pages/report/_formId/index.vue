<style lang="scss" scoped>
.search {
  width: 200px;
}
.add {
  cursor: pointer;
  height: 40px;
  line-height: 40px;
  float: right;
}
.list {
  width: 100%;
  position: relative;
  padding-bottom: 20px;
  line-height: 20px;
  border-bottom: 1px solid #e0e0e0;
  margin-bottom: 40px;
  .title {
    font-size: 18px;
    margin-bottom: 10px;
    line-height: 24px;
  }
  .range {
    font-size: 12px;
    .time {
      color: #999;
      margin-right: 10px;
    }
  }
  .btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: 20px;
    display: none;
  }
  &:hover {
    .btn {
      display: block;
    }
  }
}
.divider {
  margin: 4px 10px 0;
}
/deep/ {
  .el-button + .el-button {
    margin-left: 0;
  }
}
</style>

<template>
  <div class="page">
    <div class="container">
      <div class="clearfix mb60">
        <el-input class="fl search" placeholder="搜索报表名..." v-model="key">
          <i slot="suffix" class="el-input__icon el-icon-search" @click="search"></i>
        </el-input>
        <div @click="showShadow('新建')" class="add" v-if="formId">
          <i class="el-icon-plus mr10"></i>
          新建报表
        </div>
      </div>
      <div class="mt30">
        <div class="list mb20" v-for="item in details.content" :key="item.id">
          <div class="title">{{item.reportName}}</div>
          <div class="range">
            <div>
              <span class="time">创建时间:</span>
              {{$momentFormat(item.createTime)}}
            </div>
            <div>
              <span class="time">所属问卷:</span>
              {{item.formName}}
            </div>
          </div>
          <div class="mt20">
            <nuxt-link :to="`/report/${formId ? formId : item.formId}/${item.id}/detail`">
              <span class="pointer">详情数据</span>
            </nuxt-link>
            <div class="divider"></div>
            <nuxt-link :to="`/report/${formId ? formId : item.formId}/${item.id}/analysis`">
              <span class="pointer">分析报告</span>
            </nuxt-link>
          </div>
          <div class="btn">
            <nuxt-link :to="`/report/${formId ? formId : item.formId}/${item.id}/setting`">
              <el-button size="small" type="primary">编辑</el-button>
            </nuxt-link>
            <el-button size="small" type="primary">分享</el-button>
            <el-button
              size="small"
              type="primary"
              @click="delete1(item.id)"
              :disabled="item.defaultReport"
            >删除</el-button>
          </div>
        </div>
      </div>
      <nodata v-if="!details.content.length" class="mb80"></nodata>
      <div class="clearfix">
        <el-pagination
          @current-change="pageChange"
          :current-page="pageNo"
          :page-size="pageSize"
          layout="total, prev, pager, next"
          :total="total"
          class="fr"
        ></el-pagination>
      </div>
      <el-dialog width="400px" :title="name" :visible.sync="show">
        <el-form label-position="top" label-width="80px" :model="form">
          <el-form-item label="报表名称">
            <el-input v-model="form.name"></el-input>
          </el-form-item>
          <el-form-item label="报表描述">
            <el-input v-model="form.desc"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="hideShadow" size="small">取 消</el-button>
          <el-button type="primary" size="small" @click="submit">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import pager from '@/mixin/pager';
import nodata from '@/components/ui/noData';
export default {
  mixins: [pager],
  components: {
    nodata,
  },
  beforeRouteEnter(to, from, next) {
    next();
  },
  async asyncData({ app }) {
    app.store.commit('pager/pageSize', 10);
    let formId = app.context.params.formId ? app.context.params.formId : '';
    let res = formId
      ? await app.$axios.$get(`/report`, {
          params: {
            formId: formId,
          },
        })
      : await app.$axios.$get(`/report/list`);
    return {
      details: res,
      total: res.totalElements,
      formId,
    };
  },
  computed: {},
  data() {
    return {
      show: false,
      name: '新建',
      key: '',
      form: {
        name: '',
        desc: '',
      },
    };
  },
  mounted() {
    console.log(this.details);
  },
  methods: {
    async getData() {
      try {
        let res = await this.$axios.$get(`/report`, {
          params: {
            formId: this.formId,
          },
        });
        this.details = res;
        this.total = res.totalElements;
      } catch (err) {}
    },
    showShadow(str) {
      this.name = str;
      this.form = {
        name: '',
        desc: '',
      };
      this.show = true;
    },
    hideShadow() {
      this.show = false;
    },
    search() {
      this.$router.push({
        path: this.$route.path,
        query: {
          key: this.key,
        },
      });
    },
    async submit() {
      try {
        if (!this.form.name) {
          return this.$message.error('项目名称不能为空');
        }
        await this.create();
        this.getData();
        this.hideShadow();
      } catch (err) {}
    },
    async create() {
      return await this.$axios.$post(`/report`, {
        formId: this.formId,
        reportName: this.form.name,
        reportDescription: this.form.desc,
      });
    },
    async delete1(id) {
      try {
        await this.$confirm('确认删除报表?');
        await this.$axios.$delete(`/report/${id}`);
        this.getData();
      } catch (err) {}
    },
  },
};
</script>

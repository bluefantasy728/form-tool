<script>
import Index from './_formId/index';
export default Index;
</script>

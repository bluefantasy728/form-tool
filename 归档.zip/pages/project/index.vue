<style lang="scss" scoped src="./index.scss">
</style>

<template>
  <div class="page">
    <div class="container">
      <div class="clearfix mb40">
        <el-input class="fl search" placeholder="搜索项目名..." v-model="key">
          <i slot="suffix" class="el-input__icon el-icon-search pointer" @click="search()"></i>
        </el-input>
        <div @click="showShadow('新建项目')" class="addBtn">
          <i class="el-icon-plus mr10"></i>
          新建项目
        </div>
      </div>
      <div class="clearfix">
        <nuxt-link
          tag="div"
          :to="`/project/${item.id}/form`"
          class="item"
          v-for="(item,index) in details.content"
          :key="item.id"
        >
          <el-card>
            <div class="info">
              <div class="title line1" :title="item.projectDesc">{{item.projectName}}</div>
              <div
                class="mb70 font12"
              >{{item.processingCount + item.unStartCount + item.endCount}} 个问卷</div>
            </div>
            <div class="state">
              <div>
                <span class="n">{{item.processingCount}}</span>进行中
              </div>
              <div class="divider"></div>
              <div>
                <span class="n">{{item.unStartCount}}</span>未开始
              </div>
              <div class="divider"></div>
              <div>
                <span class="n">{{item.endCount}}</span>已结束
              </div>
            </div>
            <el-popover
              placement="bottom"
              trigger="click"
              :open-delay="0"
              transition="el-zoom-in-top"
              popper-class="btns"
            >
              <i class="el-icon-more action" slot="reference" @click.stop></i>
              <div class="btn" @click.stop="showShadow('编辑项目',item)">编辑</div>
              <div class="btn">分享</div>
              <div class="btn" @click.stop="user()">用户</div>
              <div class="btn">删除</div>
            </el-popover>
          </el-card>
        </nuxt-link>
      </div>
      <nodata v-if="!details.content.length" class="mb80"></nodata>
      <div class="clearfix">
        <el-pagination
          @current-change="pageChange"
          :current-page="pageNo"
          :page-size="pageSize"
          layout="total, prev, pager, next"
          :total="total"
          class="fr"
        ></el-pagination>
      </div>
      <el-dialog width="400px" :title="name" :visible.sync="show">
        <el-form label-position="top" label-width="80px" :model="form">
          <el-form-item label="项目名称">
            <el-input v-model="form.name"></el-input>
          </el-form-item>
          <el-form-item label="项目描述">
            <el-input v-model="form.desc"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="hideShadow" size="small">取 消</el-button>
          <el-button type="primary" @click="submit" size="small">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import pager from '@/mixin/pager';
import nodata from '@/components/ui/noData';
export default {
  mixins: [pager],
  async asyncData({ app }) {
    let key = app.context.query.key;
    app.store.commit('pager/pageSize', 12);
    let res = await app.$axios.$get(`/project`, {
      params: {
        pname: key,
      },
    });
    return {
      details: res,
      total: res.totalElements,
      key,
    };
  },
  components: {
    nodata,
  },
  computed: {},
  data() {
    return {
      key: '',
      show: false,
      name: '新建项目',
      form: {},
    };
  },
  methods: {
    async getData() {
      try {
        this.$store.commit('pager/pageNo', 1);
        let res = await this.$axios.$get(`/project`, {
          params: {
            pname: this.key,
          },
        });
        this.details = res;
        this.total = res.totalElements;
      } catch (err) {
        this.$message.error(err.message);
      }
    },
    search() {
      this.$router.push({
        path: this.$route.path,
        query: {
          key: this.key,
        },
      });
    },
    showShadow(str, obj) {
      this.name = str;
      if (obj) {
        this.form = {
          id: obj.id,
          name: obj.projectName,
          desc: obj.projectDesc,
        };
      } else {
        this.form = {
          id: '',
          name: '',
          desc: '',
        };
      }
      this.show = true;
    },
    async submit() {
      try {
        if (!this.form.name) {
          return this.$message.error('项目名称不能为空');
        }
        if (!this.form.id) {
          await this.create();
        } else {
          await this.update();
        }
        this.getData();
        this.hideShadow();
      } catch (err) {}
    },
    async create() {
      return await this.$axios.$post(`/project`, {
        projectName: this.form.name,
        projectDesc: this.form.desc,
      });
    },
    async update() {
      return await this.$axios.$put(`/project/${this.form.id}`, {
        projectName: this.form.name,
        projectDesc: this.form.desc,
      });
    },
    hideShadow() {
      this.show = false;
    },
    user(id) {
      this.$router.push('/user');
    },
  },
  mounted() {},
};
</script>

<style lang="scss" scoped>
.time {
  width: 400px;
  margin-right: 30px;
}
.title {
  font-size: 18px;
  margin-bottom: 10px;
  width: 140px;
  line-height: 24px;
}

.wrap {
  width: 100%;
  position: relative;
  padding-bottom: 10px;
  line-height: 20px;
  border-bottom: 1px solid #000;

  .btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: 20px;
    display: none;
  }
  &:hover {
    .btn {
      display: block;
    }
  }
}
.tableimg {
  width: 30px;
  height: 30px;
}
</style>

<template>
  <div class="page">
    <div class="container">
      <div class="clearfix">
        <div class="title fl">{{details.formName}}</div>
        <el-button class="fr" @click="download">导出</el-button>
        <el-date-picker
          class="fr time"
          v-model="dateValue"
          type="daterange"
          align="right"
          unlink-panels
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :picker-options="pickerOptions"
          @change="changeDate"
        ></el-date-picker>
      </div>
      <div class="mt30">
        <el-table :data="details.data.content" style="width: 100%">
          <el-table-column
            v-for="(item,index) in details.keys"
            :key="item.uuid"
            :label="item.title"
            :prop="item.uuid"
            :width="index == details.keys.length - 1 ? 'auto' : '180'"
            :show-overflow-tooltip="true"
          >
            <template slot-scope="scope">
              <div v-if="scope.row[item.uuid] && item.com == 'zuploaderImg'">
                <a
                  target="_blank"
                  v-for="(item2,index2) in JSON.parse(scope.row[item.uuid] ? scope.row[item.uuid] : '')"
                  :key="index2"
                  :href="item2"
                >
                  <img class="tableimg" :src="item2" alt="">
                </a>
              </div>
              <div v-else-if="scope.row[item.uuid] && item.com == 'zuploaderFile'">
                <span
                  v-for="(item2,index2) in JSON.parse(scope.row[item.uuid] ? scope.row[item.uuid] : '')"
                  :key="index2"
                >{{index2 == JSON.parse(scope.row[item.uuid] ? scope.row[item.uuid] : '').length - 1 ? item2.name : (item2.name + ',')}}</span>
              </div>
              <span v-else>{{scope.row[item.uuid]}}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="clearfix">
        <el-pagination
          @current-change="pageChange"
          :current-page="pageNo"
          :page-size="pageSize"
          layout="total, prev, pager, next"
          :total="total"
          class="fr"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import pager from '@/mixin/pager';
export default {
  mixins: [pager],
  async asyncData({ app }) {
    app.store.commit('pager/pageSize', 20);
    let formId = app.context.params.formId;
    let res = await app.$axios.$get(`/form/${formId}/data`);
    if (res.data.content.length) {
      res.data.content = res.data.content.map(v => {
        let obj = {};
        v.map(s => {
          obj[s.uuid] = s.value;
        });
        return obj;
      });
    }
    return {
      details: res,
      total: res.totalElements,
      formId,
    };
  },
  components: {},
  beforeRouteEnter(to, from, next) {
    next();
  },
  computed: {},

  data() {
    return {
      show: false,
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit('pick', [start, end]);
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit('pick', [start, end]);
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit('pick', [start, end]);
            },
          },
        ],
      },
      dateValue: [''],
    };
  },
  mounted() {},
  methods: {
    async getData() {
      try {
        let data = this.dateValue[0]
          ? {
              startTime: Date.parse(this.dateValue[0]),
              endTime: Date.parse(this.dateValue[1]),
            }
          : {
              startTime: '',
              endTime: '',
            };
        let res = await this.$axios.$get(`/form/${this.formId}/data`, {
          params: {
            startTime: data.startTime,
            endTime: data.endTime,
          },
        });
        if (res.data.content.length) {
          res.data.content = res.data.content.map(v => {
            let obj = {};
            v.map(s => {
              obj[s.uuid] = s.value;
            });
            return obj;
          });
        }
        this.details = res;
        this.total = res.totalElements;
      } catch (err) {}
    },
    async changeDate() {
      this.getData();
    },
    async download() {
      try {
        let data = this.dateValue[0]
          ? {
              startTime: Date.parse(this.dateValue[0]),
              endTime: Date.parse(this.dateValue[1]),
            }
          : {
              startTime: '',
              endTime: '',
            };
        let res = await this.$axios.$get(`/token`);
        window.open(
          `${process.env.baseUrl}/form/download/${this.formId}?startDate=${
            data.startTime
          }&endDate=${data.startTime}&token=${res.token}`,
        );
      } catch (err) {}
    },
  },
};
</script>

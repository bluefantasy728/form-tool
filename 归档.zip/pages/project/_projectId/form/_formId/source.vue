<style lang="scss" scoped>
</style>

<template>
  <div class="page">
    <div class="container">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="`/project`">项目-项目名称</el-breadcrumb-item>
        <el-breadcrumb-item :to="`/project/${projectId}/form`">问卷-问卷名称</el-breadcrumb-item>
        <el-breadcrumb-item>来源</el-breadcrumb-item>
      </el-breadcrumb>
      <div class="clearfix">
        <div @click="showDialog('生成链接')" class="addBtn">
          <i class="el-icon-plus mr10"></i>
          添加链接
        </div>
      </div>
      <div class>
        <el-table :data="list" style="width: 100%">
          <el-table-column prop="link" label="问卷链接" width="640">
            <template slot-scope="scope">
              <a :href="link(scope.row)" target="_blank" class="link">{{link(scope.row)}}</a>
            </template>
          </el-table-column>
          <el-table-column prop="formSourceType" label="来源名称"></el-table-column>
          <el-table-column prop="address" label="嵌入网页">
            <template slot-scope="scope">
              <el-button size="mini" @click>查看</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="address" label="二维码">
            <template slot-scope="scope">
              <el-button size="mini" @click="showQrcode(scope.row)">查看</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="address" label="操作">
            <template slot-scope="scope" v-if="scope.row.formSourceType">
              <el-button size="mini" @click="del(scope.row)" type="danger">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <el-dialog width="400px" :title="title" :visible.sync="dialog">
        <el-form label-position="top" label-width="80px" :model="form">
          <el-form-item label="来源名称">
            <el-input v-model="form.name"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialog = false" size="small">取 消</el-button>
          <el-button type="primary" size="small" @click="submit">确 定</el-button>
        </div>
      </el-dialog>
      <el-dialog
        width="400px"
        :title="`${current.name ? current.name + ' - ' : ''}二维码`"
        :visible.sync="qrcodeDialog"
      >
        <div class="alignc">
          <div class="mb20">
            <VueQrcode
              :value="current.link"
              :options="{ width: 150,margin:0 }"
              tag="img"
              ref="qrcode"
            ></VueQrcode>
          </div>
          <el-button type="primary" size="small" @click="download">下 载</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import VueQrcode from '@chenfengyuan/vue-qrcode';
import pager from '@/mixin/pager';
import download from 'downloadjs';

export default {
  mixins: [pager],
  async asyncData({ req, app }) {
    let host = '';
    let formId = app.context.params.formId;
    if (process.server) {
      host = req.headers.host;
    } else {
      host = window.location.host;
    }
    let res = await app.$axios.$get(`/project/form/${formId}/href`);
    return {
      list: [{}].concat(res),
      host,
      formId,
      base: app.context.base,
    };
  },
  components: {
    VueQrcode,
  },
  computed: {
    projectId() {
      return this.$route.params.projectId;
    },
  },

  data() {
    return {
      title: '',
      form: {
        name: '',
      },
      dialog: false,
      qrcodeDialog: false,
      current: {
        name: '',
        link: '',
      },
    };
  },
  mounted() {},
  methods: {
    async getData() {
      try {
        let res = await this.$axios.$get(`/project/form/${this.formId}/href`);
        this.list = [{}].concat(res);
      } catch (err) {}
    },
    link(item) {
      let protocol = location.protocol;
      if (item.formSourceType) {
        return `${protocol}//${this.host}${this.base}form/${
          this.formId
        }?utm_source=${this.formId}&utm_medium=${item.formSourceType}`;
      } else {
        return `${protocol}//${this.host}${this.base}form/${
          this.formId
        }?utm_source=${this.formId}`;
      }
    },
    showQrcode(item) {
      this.current = {
        name: item.formSourceType,
        link: this.link(item),
      };
      this.qrcodeDialog = true;
    },
    showDialog(title) {
      this.title = title;
      this.dialog = true;
    },
    download() {
      let el = this.$refs.qrcode.$el;
      download(el.src, `qrcode.jpg`, 'image/jpg');
    },
    async del(item) {
      try {
        await this.$confirm(`是否删除"${item.formSourceType}"来源的链接?`);
        await this.$axios.delete(`/project/form/${this.formId}/href`, {
          data: {
            formSourceType: item.formSourceType,
          },
        });
        this.getData();
      } catch (err) {}
    },
    async submit() {
      if (!this.form.name) return;
      try {
        await this.$axios.post(`/project/form/${this.formId}/href`, {
          formSourceType: this.form.name,
        });
        this.form.name = '';
        this.dialog = false;
        this.getData();
      } catch (err) {}
    },
  },
};
</script>

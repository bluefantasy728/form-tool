<style lang="scss" scoped>
</style>

<template>
  <div class="page">
    <div class="container">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item to="/project">项目-项目名称</el-breadcrumb-item>
        <el-breadcrumb-item>问卷-问卷名称</el-breadcrumb-item>
        <el-breadcrumb-item>设置</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
  </div>
</template>

<script>
export default {
  async asyncData({ req, app }) {},
  components: {},
  computed: {},
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>

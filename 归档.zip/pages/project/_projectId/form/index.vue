<style lang="scss" scoped>
.item {
  width: 100%;
  position: relative;
  padding-bottom: 20px;
  line-height: 20px;
  border-bottom: 1px solid #e0e0e0;
  margin-bottom: 40px;
  .title {
    font-size: 18px;
    margin-bottom: 10px;
    line-height: 24px;
  }
  .range {
    font-size: 12px;
    .time {
      color: #999;
      margin-right: 10px;
    }
  }
  .btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: 20px;
    display: none;
  }
  &:hover {
    .btn {
      display: block;
    }
  }
}
.divider {
  margin: 4px 10px 0;
}
/deep/ {
  .el-date-editor .el-range-input,
  .el-range-editor.el-input__inner {
    width: 100%;
  }
  .el-date-editor .el-range-separator {
    padding: 0;
    margin: 0 5px;
  }
}
</style>

<template>
  <div class="page">
    <div class="container">
      <div class="clearfix mb40">
        <div @click="showShadow('新建问卷')" class="addBtn">
          <i class="el-icon-plus mr10"></i>
          新建问卷
        </div>
      </div>
      <div class="list">
        <div class="item" v-for="(item,index) in details.content" :key="item.id">
          <div class="title clearfix">
            <el-switch
              class="mr10"
              v-model="item.disable"
              active-color="#13ce66"
              @change="disable($event, item)"
            ></el-switch>
            <span>{{item.formName}}</span>
          </div>
          <div class="range">
            <div>
              <span class="time">开始时间:</span>
              {{$momentFormat(item.formStartDate)}}
            </div>
            <div>
              <span class="time">结束时间:</span>
              {{$momentFormat(item.formEndDate)}}
            </div>
          </div>
          <div class="mt20">
            <nuxt-link class="pointer" :to="`/project/${projectId}/form/${item.id}/detail`">详情数据</nuxt-link>
            <div class="divider"></div>
            <nuxt-link class="pointer" :to="`/project/${projectId}/form/${item.id}/source`">来源</nuxt-link>
            <div class="divider"></div>
            <nuxt-link class="pointer" :to="`/report/${item.id}`">报表</nuxt-link>
            <div class="divider"></div>
            <!-- <nuxt-link class="pointer" :to="`/project/${projectId}/form/${item.id}/setting`">设置</nuxt-link> -->
            <span class="pointer" @click="showShadow('设置问卷',item)">设置</span>
            <div class="divider"></div>
            <nuxt-link
              class="pointer"
              :to="`/report/${item.id}/${item.defaultReportId}/analysis`"
            >分析报告</nuxt-link>
            <div class="divider"></div>
            <span class="pointer">行为日志</span>
          </div>
          <div class="btn">
            <nuxt-link :to="`/builder?id=${item.id}`">
              <el-button size="small" type="primary">编辑</el-button>
            </nuxt-link>
            <el-button size="small" type="primary">分享</el-button>
          </div>
        </div>
      </div>
      <nodata v-if="!details.content.length" class="mb80"></nodata>
      <div class="clearfix">
        <el-pagination
          @current-change="pageChange"
          :current-page="pageNo"
          :page-size="pageSize"
          layout="total, prev, pager, next"
          :total="total"
          class="fr"
        ></el-pagination>
      </div>
      <el-dialog width="400px" :title="name" :visible.sync="show">
        <el-form label-position="top" label-width="80px" :model="form">
          <el-form-item label="问卷名称">
            <el-input v-model="form.name"></el-input>
          </el-form-item>
          <el-form-item label="问卷描述">
            <el-input v-model="form.desc"></el-input>
          </el-form-item>
          <el-form-item label="开始时间 - 结束时间">
            <el-date-picker
              v-model="form.date"
              type="datetimerange"
              range-separator="至"
              start-placeholder="开始时间"
              end-placeholder="结束时间"
              :clearable="false"
              :picker-options="options"
            ></el-date-picker>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="hideShadow" size="small">取 消</el-button>
          <el-button type="primary" size="small" @click="submit">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import pager from '@/mixin/pager';
import nodata from '@/components/ui/noData';
export default {
  mixins: [pager],
  components: {
    nodata,
  },
  async asyncData({ app }) {
    app.store.commit('pager/pageSize', 10);
    let projectId = app.context.params.projectId;
    let res = await app.$axios.$get(`/project/${projectId}/form`);
    // res.content.map(item => {
    //   item.disable = !item.disable;
    // });
    return {
      details: res,
      total: res.totalElements,
      projectId,
    };
  },
  computed: {},
  data() {
    return {
      show: false,
      name: '',
      state: false,
      form: {},
      options: {
        disabledDate(time) {
          return time.getTime() < new Date().getTime() - 3600 * 1000 * 24;
        },
      },
    };
  },
  mounted() {
    console.log(this.details);
  },
  methods: {
    async getData() {
      try {
        let res = await this.$axios.$get(`/project/${this.projectId}/form`);
        this.details = res;
        this.total = res.totalElements;
      } catch (err) {}
    },
    showShadow(str, obj) {
      this.name = str;
      if (obj) {
        this.form = {
          id: obj.id,
          name: obj.formName,
          desc: obj.formDesc,
          date: [obj.formStartDate, obj.formEndDate],
          disable: obj.disable,
        };
      } else {
        this.form = {
          id: '',
          name: '',
          desc: '',
          date: [],
        };
      }
      this.show = true;
    },
    hideShadow() {
      this.show = false;
    },
    async disable(val, obj) {
      try {
        this.form = {
          id: obj.id,
          name: obj.formName,
          desc: obj.formDesc,
          date: [obj.formStartDate, obj.formEndDate],
          disable: val,
        };
        await this.update();
      } catch (err) {}
    },
    async create() {
      return await this.$axios.$post(`/project/${this.projectId}/form`, {
        formName: this.form.name,
        formDesc: this.form.desc,
        formStartDate: Date.parse(this.form.date[0]),
        formEndDate: Date.parse(this.form.date[1]),
      });
    },
    async update() {
      return await this.$axios.$put(`/project/form/${this.form.id}`, {
        formName: this.form.name,
        formDesc: this.form.desc,
        formStartDate: Date.parse(this.form.date[0]),
        formEndDate: Date.parse(this.form.date[1]),
        disable: this.form.disable ? this.form.disable : false,
      });
    },
    async submit() {
      try {
        if (!this.form.name) {
          return this.$message.error('项目名称不能为空');
        }
        if (!this.form.date.length) {
          return this.$message.error('请选择开始时间结束时间');
        }
        if (!this.form.id) {
          await this.create();
        } else {
          await this.update();
        }
        this.getData();
        this.hideShadow();
      } catch (err) {}
    },
  },
};
</script>

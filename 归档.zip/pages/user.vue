<style lang="scss" scoped>
.container {
  width: 1000px;
  padding-top: 100px;
  margin: 0 auto;
  overflow: hidden;
  .left {
    float: left;
    width: 200px;
    ul {
      height: 200px;
      display: flex;
      justify-content: space-between;
      flex-flow: column;
      li {
        cursor: pointer;
        font-size: 18px;
        line-height: 40px;
        height: 40px;
        width: 130px;
        padding-left: 10px;
        position: relative;
        transition: all linear 0.2s;
        left: 0;
        &.select {
          border-bottom: 1px solid #000;
          left: 20px;
          &::after {
            content: '';
            width: 0;
            height: 0;
            border-left: 10px solid #000;
            border-top: 5px solid transparent;
            border-bottom: 5px solid transparent;
            position: absolute;
            left: -20px;
            top: 50%;
            transform: translateY(-50%);
          }
        }
      }
    }
  }
  .right {
    float: left;
    width: 750px;
  }
}
</style>

<template>
  <div class="page">
    <div class="container">
      <headers></headers>
      <div class="left">
        <ul>
          <li :class="{select: index === '/user'}" @click="changeSelect('/user')">通用用户字段</li>
          <li :class="{select: index == '/user/data'}" @click="changeSelect('/user/data')">用户数据</li>
          <li
            :class="{select: index == '/user/label' || index == '/user/newlabel'}"
            @click="changeSelect('/user/label')"
          >用户标签</li>
        </ul>
      </div>
      <nuxt-child class="right"/>
    </div>
  </div>
</template>

<script>
import headers from '@/components/header';
export default {
  components: {
    headers,
  },
  computed: {},
  data() {
    return {
      index: '',
    };
  },
  watch: {
    '$route.path'() {
      this.index = this.$route.path;
    },
  },
  created() {
    this.index = this.$route.path;
  },
  mounted() {},
  methods: {
    changeSelect(index) {
      this.index = index;
      this.$router.push(index);
    },
  },
};
</script>

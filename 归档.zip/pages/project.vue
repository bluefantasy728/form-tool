<style lang="scss" scoped>
/deep/ {
  .page {
    background: #f8f8f8;
  }
}
</style>

<template>
  <div class="page">
    <headers></headers>
    <nuxt-child/>
  </div>
</template>

<script>
import headers from '@/components/header';
export default {
  components: {
    headers,
  },
  computed: {},
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>

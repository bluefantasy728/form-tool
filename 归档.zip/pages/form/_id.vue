<style lang="scss" scoped>
@import '@/assets/scss/theme/index.scss';

.mobileBox {
  position: fixed;
  top: 160px;
  left: calc(50% + 375px + 30px);
  border: 1px solid #e0e0e0;
  text-align: center;
  padding: 10px 20px;
  .title {
    padding: 8px 0;
    margin-bottom: 10px;
  }
}
</style>

<template>
  <div v-if="show">
    <no-ssr v-if="show2">
      <div class="mobileBox">
        <div class="title">移动端访问</div>
        <VueQrcode :value="`${protocol}//${path}`" :options="{ width: 100,margin:0 }" tag="img"></VueQrcode>
      </div>
    </no-ssr>
    <div id="page">
      <component
        :is="item.com"
        :store="item.props"
        :uuid="item.uuid"
        v-for="(item,index) in mods"
        :key="item.uuid"
        v-model="item.field"
      ></component>
      <div class="alignc">
        <el-button type="success" @click="submit" class="mt40">提 交</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import VueQrcode from '@chenfengyuan/vue-qrcode';
import { dr } from '@/utils';
import ztext from '@/components/mod/ztext';
import zinput from '@/components/mod/zinput';
import zselect from '@/components/mod/zselect';
import zdate from '@/components/mod/zdate';
import ztime from '@/components/mod/ztime';
import zdateTime from '@/components/mod/zdateTime';
import zdivider from '@/components/mod/zdivider';
import ztextarea from '@/components/mod/ztextarea';
import zimage from '@/components/mod/zimage';
import zcurrency from '@/components/mod/zcurrency';
import zuploaderImg from '@/components/mod/zuploaderImg';
import zuploaderFile from '@/components/mod/zuploaderFile';
import zradio from '@/components/mod/zradio';
import zcheckbox from '@/components/mod/zcheckbox';
import zsort from '@/components/mod/zsort';
import zrate from '@/components/mod/zrate';
import zswiper from '@/components/mod/zswiper';

export default {
  layout: 'mobile',
  components: {
    VueQrcode,
    ztext,
    zinput,
    zselect,
    zdate,
    ztime,
    zdateTime,
    zdivider,
    ztextarea,
    zimage,
    zcurrency,
    zuploaderImg,
    zradio,
    zcheckbox,
    zuploaderFile,
    zsort,
    zrate,
    zswiper,
  },
  async asyncData({ req, app }) {
    let id = app.context.params.id;
    let path = app.context.route.fullPath;
    let status = 2;
    let preview = false;
    let host = '';
    if (process.server) {
      host = req.headers.host;
    } else {
      host = window.location.host;
    }
    if (path.includes('preview')) {
      status = 1;
      preview = true;
    }
    let res = await app.$axios.$get(`/form/${id}/config`, {
      params: {
        status,
      },
    });
    let mods = res.formConfig ? res.formConfig.formConfig : [];
    return {
      mods,
      id,
      details: res,
      preview,
      path: host + app.context.base.slice(0, -2) + path,
    };
  },
  computed: {},
  data() {
    return {
      protocol: '',
      show: false,
      show2: false,
    };
  },
  methods: {
    async submit() {
      window.t.push('打开', '问卷');
      try {
        let data = [];
        console.log(this.mods);
        this.mods.forEach((item, index) => {
          if (item.editable) {
            if (!item.field.validated) {
              throw {
                message: item.field.message,
              };
            } else {
              data.push({
                uuid: item.uuid,
                value: item.field.value,
                com: item.com,
              });
            }
          }
        });
        console.log(data);
        if (!this.preview) {
          await this.postData(data);
        }
        this.$message.success('提交成功');
      } catch (err) {
        this.$message.error(err.message);
      }
    },
    async postData(data) {
      try {
        await this.$axios.post(`/form/${this.id}/data`, {
          formData: data,
        });
        t.push('提交', '问卷');
      } catch (err) {}
    },
  },
  async mounted() {
    this.protocol = window.location.protocol;
    if (this.preview) {
      this.$notify.info({
        title: '提示',
        position: 'bottom-right',
        message: '当前为预览模式，不会真实提交数据',
        showClose: false,
        duration: 0,
      });
      this.show2 = true;
    } else {
      let date = new Date().getTime();
      if (
        date > this.details.form.formEndDate ||
        date < this.details.form.formStartDate ||
        !this.details.form.disable
      ) {
        this.show = false;
        this.$notify.info({
          title: '提示',
          position: 'top-center',
          message: '问卷未开始',
          showClose: false,
          duration: 0,
        });
        alert('问卷未开始');
      } else {
        this.show = true;
      }
      let drObj = dr(this.details.project.drAccountKey, {
        utm_source: 'utm_source',
      });
      drObj.onload = () => {
        setTimeout(() => {
          t.push('打开', '问卷');
        }, 1000);
      };
    }
  },
};
</script>

<style lang="scss" scoped>
.tab {
  margin-left: 50px;
}
.ipt {
  width: 300px;
}
.card {
  width: 100%;
}
</style>
<template>
  <div class="tab">
    <div class="mb30">标签名
      <el-input class="ipt"></el-input>
    </div>
    <div class="mb30">条件</div>
    <el-card class="card">
      <el-table :data="tableData" tooltip-effect="dark" style="width: 100%">
        <el-table-column label="问卷名">
          <template slot-scope="scope">
            <el-select size="small" v-model="scope.row.name" placeholder="label">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="字段名">
          <template slot-scope="scope">
            <el-select size="small" v-model="scope.row.name" placeholder="label">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="操作符">
          <template slot-scope="scope">
            <el-select size="small" v-model="scope.row.name" placeholder="label">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="比较值">
          <template slot-scope="scope">
            <el-input placeholder="Placeholder" v-model="scope.row.name"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="">
          <template slot-scope="scope">
            <el-button size="small" icon="el-icon-plus" @click="plus"></el-button>
            <el-button size="small" icon="el-icon-minus" @click="minus(scope.$index)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="mt30">
        <el-radio label="1">全部满足</el-radio>
        <el-radio label="1">一项满足</el-radio>
      </div>
      <div>
        <el-button class="mt30" size="small" @click="save">保存</el-button>
      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  components: {},
  computed: {},
  data() {
    return {
      tableData: [{}],
      options: [],
    };
  },
  mounted() {},
  methods: {
    plus() {
      this.tableData.push({});
    },
    minus(index) {
      this.tableData.splice(index, 1);
    },
    save() {
      this.$confirm('是否需要对以前标签数据做更新', '提示', {
        confirmButtonText: '需要',
        cancelButtonText: '不需要',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '保存成功!',
          });
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消保存',
          });
        });
    },
  },
};
</script>

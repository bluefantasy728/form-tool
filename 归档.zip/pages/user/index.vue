<style lang="scss" scoped>
.tab {
  margin-left: 50px;
}
.line {
  width: 300px;
  .el-input {
    margin: 20px 0;
  }
}
</style>
<template>
  <div class="tab">
    <el-table :data="tableData" style="width: 100%">
      <el-table-column align="center" label="唯一标识" width="120">
        <template slot-scope="scope">
          <el-radio v-model="radio" :label="scope.row.label" value="">&nbsp;</el-radio>
        </template>
      </el-table-column>
      <el-table-column header-align="center" label="字段名" width="180">
        <template slot-scope="scope">
          <el-select size="small" v-model="scope.row.name" placeholder="请选择">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </template>
      </el-table-column>
      <el-table-column align="center" label="" width="120">
        <template slot-scope="scope">
          <el-button size="small" @click="set">设置</el-button>
        </template>
      </el-table-column>
      <el-table-column label="" width="180">
        <template slot-scope="scope">
          <el-button size="small" icon="el-icon-plus"></el-button>
          <el-button size="small" icon="el-icon-minus"></el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="clearfix mt30">
      <el-button class="fr">保存</el-button>
    </div>
    <el-dialog width="400px" title="设置" :visible.sync="show">
      <div class="line">
        <div>问卷名称:</div>
        <el-input></el-input>
      </div>
      <div class="line">
        <div>问卷描述:</div>
        <el-input></el-input>
      </div>
      <div class="line">
        <div>开始时间:</div>
        <el-input></el-input>
      </div>
      <div class="line">
        <div>结束时间:</div>
        <el-input></el-input>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="hideShadow">取 消</el-button>
        <el-button type="primary" @click="hideShadow">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  components: {},
  computed: {},
  data() {
    return {
      radio: '',
      show: false,
      tableData: [
        {
          name: '字段名',
          name2: '王小虎',
          checked: false,
          compare: '',
          label: '1',
        },
        {
          name: '字段名',
          name2: '王小虎',
          checked: false,
          compare: '',
          label: '2',
        },
        {
          name: '字段名',
          name2: '王小虎',
          checked: false,
          compare: '',
          label: '3',
        },
        {
          name: '字段名',
          name2: '王小虎',
          checked: false,
          compare: '',
          label: '4',
        },
      ],
      options: ['姓名'],
    };
  },
  mounted() {},
  methods: {
    set() {
      this.show = true;
    },
    hideShadow() {
      this.show = false;
    },
  },
};
</script>

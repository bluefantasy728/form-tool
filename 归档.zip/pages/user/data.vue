<style lang="scss" scoped>
.tab {
  padding-left: 50px;
}
.line {
  width: 300px;
  font-size: 18px;
  color: #000;
  + div {
    margin: 10px 0;
  }
}
.search {
  width: 200px;
  margin-left: 30px;
}
.tag {
  display: inline-block;
  margin-right: 10px;
  border: 1px solid rgba(230, 162, 60, 0.2);
  background: rgba(230, 162, 60, 0.1);
  color: #e6a23c;
  padding: 0 10px;
  height: 32px;
  line-height: 30px;
  font-size: 12px;
  border-radius: 4px;
  white-space: nowrap;
}
</style>
<template>
  <div class="tab">
    <div class="clearfix">
      <el-tag class="fl mr10" v-for="tag in tags" :key="tag.name" type="warning">{{tag.name}}</el-tag>
      <el-input class="fr search" placeholder="search" v-model="search">
        <i slot="suffix" class="el-input__icon el-icon-search"></i>
      </el-input>
      <el-button class="fr" @click="showShadow">筛选</el-button>
    </div>
    <el-table class="mt50" :data="tableData" style="width: 100%">
      <el-table-column label="" width="100">
        <template slot-scope="scope">
          <el-button size="mini" icon="el-icon-search"></el-button>
        </template>
      </el-table-column>
      <el-table-column prop="name" label="姓名" width="120"></el-table-column>
      <el-table-column prop="date" label="日期" width="180"></el-table-column>
      <el-table-column prop="address" label="地址"></el-table-column>
    </el-table>
    <div class="clearfix mt30">
      <el-button class="fr">导出</el-button>
    </div>
    <el-dialog width="400px" :visible.sync="show" :show-close="false">
      <div class="line">已选标签</div>
      <div>
        <div
          class="tag mb10"
          size="mini"
          type="warning"
          v-for="(tag,index) in selectedTags"
          :key="index"
        >
          {{tag.name}}
          <i class="el-icon-close el-icon--right" @click="unselect(index)"></i>
        </div>
      </div>
      <div class="clearfix mb30">
        <el-radio class="fr ml20" label="1">一项满足</el-radio>
        <el-radio class="fr" label="1">全部满足</el-radio>
      </div>
      <div class="line">未选标签</div>
      <div>
        <div
          class="tag mb10"
          size="mini"
          type="warning"
          v-for="(tag,index) in unselectedTags"
          :key="index"
        >
          {{tag.name}}
          <i class="el-icon-plus el-icon--right" @click="select(index)"></i>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="hideShadow">取 消</el-button>
        <el-button type="primary" @click="hideShadow">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  components: {},
  computed: {},
  data() {
    return {
      radio: '',
      show: false,
      search: '',
      tags: [
        { name: '标签一', type: '' },
        { name: '标签二', type: 'success' },
        { name: '标签三', type: 'info' },
        { name: '标签四', type: 'warning' },
      ],
      selectedTags: [
        { name: '标签一', type: '' },
        { name: '标签二', type: 'success' },
        { name: '标签三', type: 'info' },
        { name: '标签四', type: 'warning' },
      ],
      unselectedTags: [
        { name: '标签一', type: '' },
        { name: '标签二', type: 'success' },
        { name: '标签三', type: 'info' },
        { name: '标签四', type: 'warning' },
        { name: '标签四', type: 'warning' },
      ],
      tableData: [
        {
          date: '2016-05-02',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-04',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1517 弄',
        },
        {
          date: '2016-05-01',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1519 弄',
        },
        {
          date: '2016-05-03',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1516 弄',
        },
      ],
      options: ['姓名'],
    };
  },
  mounted() {},
  methods: {
    showShadow() {
      this.show = true;
    },
    hideShadow() {
      this.show = false;
    },
    select(index) {
      this.selectedTags.push(...this.unselectedTags.splice(index, 1));
    },
    unselect(index) {
      this.unselectedTags.push(...this.selectedTags.splice(index, 1));
    },
  },
};
</script>

<style lang="scss" scoped>
.tab {
  margin-left: 50px;
}
.search {
  width: 400px;
}
.line {
  font-size: 18px;
  > i {
    line-height: 60px;
  }
  .btn {
    margin-top: 10px;
  }
}
.add {
  cursor: pointer;
  height: 60px;
  line-height: 60px;
  float: right;
  font-size: 14px;
}
</style>
<template>
  <div class="tab">
    <div class="mb30">
      <el-input class="search" placeholder="search" v-model="search">
        <i slot="suffix" class="el-input__icon el-icon-search"></i>
      </el-input>
    </div>
    <div class="line clearfix">
      <i class="el-icon-delete fl"></i>
      <div class="add fr">
        <nuxt-link to="/user/newlabel">
          <i class="el-icon-plus mr10"></i>
          新建标签
        </nuxt-link>
      </div>
    </div>
    <el-table
      max-height="400"
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column label="标签名称" width="120" prop="date"></el-table-column>
      <el-table-column prop="name" label="备注说明" width="120"></el-table-column>
      <el-table-column prop="address" label="建立时间"></el-table-column>
      <el-table-column prop="address" label="最近更改时间"></el-table-column>
      <el-table-column prop="address" label="当前状态"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-switch v-model="scope.row.state" active-color="#E6A23C"></el-switch>
        </template>
      </el-table-column>
    </el-table>
    <div class="clearfix mt30">
      <el-button class="fr">保存</el-button>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  computed: {},
  data() {
    return {
      search: '',
      tableData: [
        {
          date: '2016-05-03',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-02',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-04',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-01',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-08',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-06',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
        {
          date: '2016-05-07',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
        },
      ],
      multipleSelection: [],
    };
  },
  mounted() {},
  methods: {
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
  },
};
</script>

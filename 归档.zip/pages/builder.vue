<style lang="scss" scoped src="./builder.scss">
</style>

<template>
  <div class="page">
    <left></left>
    <right></right>
    <top @publish="publish" @save="save" @preview="preview" :info="details.form"></top>
    <div class="page" @click.self="active()">
      <div class="preview">
        <draggable
          :group="{ name: 'mods' }"
          @change="change"
          id="page"
          v-model="mods"
          draggable=".draggable"
        >
          <div
            class="mod-wrap draggable"
            v-for="(item,index) in mods"
            :key="item.uuid"
            @click.stop="active(item.uuid)"
            :class="{
            'active': activeid == item.uuid
          }"
          >
            <component :is="item.com" :store="item.props"></component>
            <template v-if="item.uuid == activeid">
              <el-button
                type="warning"
                icon="el-icon-plus"
                size="mini"
                circle
                class="btns copy"
                @click="copy(item,index)"
              ></el-button>
              <el-button
                type="danger"
                icon="el-icon-close"
                size="mini"
                circle
                class="btns del"
                @click="del(item,index)"
              ></el-button>
            </template>
          </div>
        </draggable>
      </div>
    </div>
    <el-dialog :visible.sync="success" width="600px">
      <div class="success">
        <i class="el-icon-success"></i>
        <div class="title">发布成功</div>
        <div>
          <nuxt-link :to="`/project/${projectID}/form/${id}/source`">
            <el-button>来源管理</el-button>
          </nuxt-link>
          <a :href="`form/${id}?utm_source=${id}`" class="ml10" target="_blank">
            <el-button type="primary">查看</el-button>
          </a>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import _ from 'lodash';
import left from '@/components/builder/left';
import right from '@/components/builder/right';
import top from '@/components/builder/top';
import draggable from 'vuedraggable';
import UUID from 'uuidjs';

import ztext from '@/components/mod/ztext';
import zinput from '@/components/mod/zinput';
import zselect from '@/components/mod/zselect';
import zdate from '@/components/mod/zdate';
import ztime from '@/components/mod/ztime';
import zdateTime from '@/components/mod/zdateTime';
import zdivider from '@/components/mod/zdivider';
import ztextarea from '@/components/mod/ztextarea';
import zimage from '@/components/mod/zimage';
import zcurrency from '@/components/mod/zcurrency';
import zuploaderImg from '@/components/mod/zuploaderImg';
import zuploaderFile from '@/components/mod/zuploaderFile';
import zradio from '@/components/mod/zradio';
import zcheckbox from '@/components/mod/zcheckbox';
import zsort from '@/components/mod/zsort';
import zrate from '@/components/mod/zrate';
import zswiper from '@/components/mod/zswiper';

export default {
  components: {
    left,
    right,
    top,
    draggable,
    ztext,
    zinput,
    zselect,
    zdate,
    ztime,
    zdateTime,
    zdivider,
    ztextarea,
    zimage,
    zcurrency,
    zuploaderImg,
    zradio,
    zcheckbox,
    zuploaderFile,
    zsort,
    zrate,
    zswiper,
  },
  async asyncData({ app }) {
    let id = app.context.query.id;
    let res = await app.$axios.$get(`/form/${id}/config`, {
      params: {
        status: 1,
      },
    });
    let mods = res.formConfig ? res.formConfig.formConfig : [];
    app.store.commit('builder/mods', mods);
    app.store.commit('builder/tab', 'view');
    return {
      details: res,
      projectID: res.form.projectID,
    };
  },

  computed: {
    mods: {
      get() {
        return this.$store.state.builder.mods;
      },
      set(value) {
        this.$store.commit('builder/mods', value);
      },
    },
    activeid() {
      return this.$store.state.builder.activeid;
    },
    id() {
      return this.$route.query.id;
    },
  },
  data() {
    return {
      success: false,
    };
  },
  watch: {},
  async mounted() {
    window.onbeforeunload = function() {
      window.event.returnValue = '确定要退出本页吗?';
    };
  },
  async beforeRouteLeave(to, from, next) {
    try {
      await this.$confirm('是否在离开前保存该模块？');
      await this.save();
      window.onbeforeunload = null;
      next();
    } catch (err) {
      window.onbeforeunload = null;
      next();
    }
  },
  methods: {
    async publish() {
      await this.$axios.post(`/form/${this.id}/config/release`, {
        formConfig: this.mods,
      });
      this.success = true;
    },
    preview() {
      window.open(`preview/${this.id}`);
    },
    async save() {
      await this.$axios.post(`/form/${this.id}/config`, {
        formConfig: this.mods,
      });
      this.$message.success('保存成功');
    },
    change(obj) {
      if (obj.added) {
        this.active(obj.added.element.uuid);
      }
    },
    copy(item, index) {
      let data = _.cloneDeep(item);
      data.uuid = UUID.generate();
      this.$store.commit('builder/copy', {
        index,
        data,
      });
    },
    async del(item, index) {
      try {
        await this.$confirm('是否移除该模块？移除后不可恢复。');
        this.$store.commit('builder/del', index);
      } catch (err) {}
    },
    active(id) {
      if (this.activeid || id) {
        this.$store.commit('builder/activeid', id);
      }
    },
  },
};
</script>


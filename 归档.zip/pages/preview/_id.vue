<script>
import Index from '../form/_id';
export default Index;
</script>

<style lang="scss" scoped>
.page {
  background: #ffd04b;
  position: relative;
  .title {
    font-weight: bold;
    font-size: 20px;
  }
  .card {
    width: 400px;
    .header {
      margin-left: 20px;
      font-size: 18px;
    }
    .content {
      padding: 20px 20px 40px 20px;
    }
    .btn {
      margin: 20px auto 10px;
      width: 100%;
    }
    .verify {
      .img {
        width: 100px;
        background: #000;
        float: right;
        > img {
          width: 100px;
          height: 40px;
        }
      }
      .ipt {
        width: 200px;
      }
    }
  }
}
</style>

<template>
  <div class="page">
    <el-card class="card center">
      <div slot="header" class="header">
        <span class="title">注 册</span>
      </div>
      <div class="content">
        <el-form
          :model="form"
          :rules="rules"
          ref="ruleForm"
          @keyup.enter.native="submit('ruleForm')"
        >
          <el-form-item prop="username">
            <el-input v-model="form.username" placeholder="邮箱"></el-input>
          </el-form-item>
          <!-- <el-form-item prop="password">
            <el-input v-model="form.password" placeholder="密码" type="password"></el-input>
          </el-form-item>
          <el-form-item prop="code" class="verify">
            <el-input class="ipt" v-model="form.code" placeholder="验证码"></el-input>
            <div class="img clearfix" @click="changeCodeUrl">
              <img class="fl" :src="randomCodeUrl" alt>
            </div>
          </el-form-item>-->

          <el-button class="btn" type="primary" @click="submit('ruleForm')">找 回 密 码</el-button>
          <div class="clearfix">
            <nuxt-link to="/login" class="pointer fl grey">登录</nuxt-link>
            <nuxt-link to="/register" class="pointer fr grey">注册</nuxt-link>
          </div>
        </el-form>
      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  async asyncData({ app }) {
    let randomSession = Math.random();
    let randomCodeUrl = `${
      process.env.baseUrl
    }/user/genRandomCode?randomSession=${randomSession}`;
    return {
      randomSession,
      randomCodeUrl,
    };
  },
  components: {},
  beforeRouteEnter(to, from, next) {
    next();
  },
  computed: {},
  data() {
    return {
      form: {
        username: '',
        // password: '',
        // code: '',
      },
      rules: {
        username: [
          {
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error('请输入用户名'));
              }
              callback();
            },
            trigger: 'blur',
          },
        ],
        password: [
          {
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error('请输入密码'));
              }
              callback();
            },
            trigger: 'blur',
          },
        ],
        code: [
          {
            validator: (rule, value, callback) => {
              if (value === '') {
                callback(new Error('请输入验证码'));
              }
              callback();
            },
            trigger: 'blur',
          },
        ],
      },
    };
  },
  mounted() {},
  methods: {
    changeCodeUrl() {
      this.randomSession = Math.random();
      this.randomCodeUrl = `${
        process.env.baseUrl
      }/user/genRandomCode?randomSession=${this.randomSession}`;
    },
    async submit(formName) {
      let _this = this;
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.login();
        }
      });
    },
    async login() {
      let res = await this.$axios.$get(`/user/${this.form.username}`);
      console.log(res);
      // this.$router.push('/login');
    },
  },
};
</script>

<style lang="scss" scoped>
</style>

<template>
  <div class="page">
    <headers></headers>
    <nuxt-child/>
  </div>
</template>

<script>
import headers from '@/components/header';
export default {
  components: {
    headers,
  },
  computed: {},
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>

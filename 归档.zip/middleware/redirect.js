export default async ({ route, redirect }) => {
  if (route.path == '/' || route.path == '/home') {
    redirect('/project');
  }
};

import Cookies from 'js-cookie';
import cookie from 'cookie';

export default async ({ app, store, route, redirect }) => {
  let cookies = {};
  if (process.server) {
    cookies = cookie.parse(app.context.req.headers.cookie || '');
  } else {
    cookies = Cookies.get();
  }

  store.commit('user/token', cookies.token);
  store.commit('user/user', cookies.user ? JSON.parse(cookies.user) : {});
};

function isWeixin() {
  return navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1;
}

function ua() {
  const ua = navigator.userAgent;
  const isIpad = ua.match(/(iPad).*OS\s([\d_]+)/);
  const isIphone = !isIpad && ua.match(/(iPhone\sOS)\s([\d_]+)/);
  const isAndroid = ua.match(/(Android)\s+([\d.]+)/);
  const isMobile = isIphone || isAndroid;
  return {
    isIpad,
    isIphone,
    isAndroid,
    isMobile,
  };
}

function dr(key, obj = {}) {
  window.ztrack = {
    key,
    ...obj,
  };
  var sc = document.createElement('script');
  sc.setAttribute(
    'src',
    document.location.protocol + '//t.datarepublic.cn/js/g.js',
  );
  sc.setAttribute('type', 'text/javascript');
  document.getElementsByTagName('head')[0].appendChild(sc);
  return sc;
}

export { isWeixin, ua, dr };

export default {
  namespaced: true,
  state() {
    return {
      token: '',
      user: {},
    };
  },
  mutations: {
    token(state, v) {
      state.token = v;
    },
    user(state, v) {
      state.user = v;
    },
  },
};

export default {
  namespaced: true,
  state() {
    return {
      dateValue: [0, 0],
      visitsCount: 0,
      downCount: 0
    };
  },
  mutations: {
    dateValue(state, v) {
      state.dateValue = v;
    },
    count(state, v) {
      state.visitsCount = v.visitsCount
      state.downCount = v.downCount
    },
  },
}

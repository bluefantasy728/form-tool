export default {
  namespaced: true,
  state() {
    return {
      pageNo: 1,
      pageSize: 10,
    };
  },
  mutations: {
    pageNo(state, v) {
      state.pageNo = v;
    },
    pageSize(state, v) {
      state.pageSize = v;
    },
  },
};

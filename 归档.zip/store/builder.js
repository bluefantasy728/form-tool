import _ from 'lodash';
import store from 'store';

export default {
  namespaced: true,
  state() {
    return {
      past: [],
      futrue: [],
      present: {},
      activeid: '',
      tab: 'view',
      //当前模块树
      mods: [],
    };
  },
  getters: {
    //活动模块
    active: state => {
      return state.mods.find(v => {
        return v.uuid == state.activeid;
      });
    },
  },
  mutations: {
    forward(state, v) {
      let index = state.past.length + 1;
      const allState = [...state.past, state.mods, ...state.futrue];
      state.mods = allState[index];
      state.past = allState.slice(0, index);
      state.futrue = allState.slice(index + 1, allState.length);
      store.set('mods', state.mods);
    },
    back(state, v) {
      let index = state.past.length - 1;
      const allState = [...state.past, state.mods, ...state.futrue];
      state.mods = allState[index];
      state.past = allState.slice(0, index);
      state.futrue = allState.slice(index + 1, allState.length);
      store.set('mods', state.mods);
    },
    //读取模块树
    load(state) {
      state.mods = store.get('mods') || [];
    },
    //更新模块树
    mods(state, v) {
      state.past.push(_.cloneDeep(state.mods));
      state.futrue = [];
      state.mods = v;
      store.set('mods', state.mods);
    },
    //删除模块
    del(state, v) {
      state.past.push(_.cloneDeep(state.mods));
      state.futrue = [];
      state.mods.splice(v, 1);
      store.set('mods', state.mods);
    },
    //复制模块
    copy(state, v) {
      state.past.push(_.cloneDeep(state.mods));
      state.futrue = [];
      state.mods.splice(v.index + 1, 0, v.data);
      store.set('mods', state.mods);
    },
    //更新模块
    update(state, v) {
      let i = state.mods.findIndex(item => {
        return item.uuid == state.activeid;
      });
      let temp = _.cloneDeep(state.mods[i]);
      if (_.isEqual(temp.props, v)) {
        return;
      }
      state.past.push(_.cloneDeep(state.mods));
      state.futrue = [];
      state.mods.splice(i, 1, { ...temp, props: _.cloneDeep(v) });
      store.set('mods', state.mods);
    },
    //编辑当前模块
    activeid(state, v) {
      state.activeid = v;
      if (v) {
        state.tab = 'edit';
      } else {
        state.tab = 'view';
      }
    },
    //设置编辑区tab
    tab(state, v) {
      state.tab = v;
    },
  },
};

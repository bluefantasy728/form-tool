export const strict = true;

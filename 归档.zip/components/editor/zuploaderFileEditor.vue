<style lang="scss" scoped>
.format-checkbox /deep/ {
  .el-form-item__content {
    display: flex;
    flex-wrap: wrap;
  }
  .el-checkbox {
    margin-top: 0 !important;
    margin-right: 20px !important;
  }
}
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.required">必填</el-checkbox>
      <el-checkbox v-model="store.hide">是否隐藏</el-checkbox>
      <el-checkbox v-model="store.isMultiple">允许上传多个文件</el-checkbox>
    </el-form-item>
    <el-form-item label="文件个数限制" v-if="store.isMultiple">
      <el-input-number v-model="store.limitQty" :min="2" size="small"></el-input-number>
    </el-form-item>
    <el-form-item label="允许文件扩展名（用英文逗号隔开）">
      <el-input v-model="store.acceptFileFormat" placeholder="例：pdf,doc" size="small"></el-input>
    </el-form-item>

    <el-form-item label="单个文件大小限制（单位：kb）">
      <el-input
        v-model.number="store.limitSize"
        size="small"
        @keyup.native="positive($event,'store.limitSize')"
      ></el-input>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  computed: {},
  components: {},
  watch: {},
  data() {
    return {};
  },
  methods: {},
  mounted() {},
};
</script>

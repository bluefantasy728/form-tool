<style lang="scss" scoped>
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item label="提示文字">
      <el-input v-model="store.placeholder" size="small"></el-input>
    </el-form-item>
    <el-form-item label="货币单位">
      <el-select v-model="store.unit" placeholder="货币单位" size="small">
        <el-option label="¥ 人民币" value="RMB"></el-option>
        <el-option label="JP¥ 日元" value="JPY"></el-option>
        <el-option label="$ 美元" value="USD"></el-option>
        <el-option label="€ 欧元" value="EUR"></el-option>
      </el-select>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.required">必填</el-checkbox>
      <el-checkbox v-model="store.hide">是否隐藏</el-checkbox>
    </el-form-item>
    <el-form-item label="最小值">
      <el-input
        v-model.number="store.min"
        size="small"
        placeholder="最小值"
        @keyup.native="positive($event,'store.min')"
      ></el-input>
    </el-form-item>
    <el-form-item label="最大值">
      <el-input
        v-model.number="store.max"
        size="small"
        placeholder="最大值"
        @keyup.native="positive($event,'store.max')"
      ></el-input>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  computed: {},
  components: {},
  data() {
    return {};
  },
  methods: {},
  mounted() {},
};
</script>

<style lang="scss" scoped>
.rate-icon {
  transform: scale(1.5);
  color: #c0c4cc;
  &.selected {
    color: #f7ba2a;
  }
}
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.required">必填</el-checkbox>
      <el-checkbox v-model="store.hide">是否隐藏</el-checkbox>
      <!-- <el-checkbox v-model="store.allowHalf">允许选择半颗星</el-checkbox> -->
      <!-- <el-checkbox v-model="store.showText">显示分值说明</el-checkbox> -->
    </el-form-item>
    <el-form-item label="图标">
      <el-radio-group v-model="store.icon">
        <el-radio :label="item" v-for="(item, index) in iconOptions" :key="index">
          <i :class="[item,'rate-icon',{selected:item===store.icon}]"></i>
        </el-radio>
        <!-- <el-radio :label="6">备选项</el-radio>
        <el-radio :label="9">备选项</el-radio>-->
      </el-radio-group>
    </el-form-item>
    <el-form-item label="图标尺寸">
      <el-input-number
        v-model="store.fontSize"
        :min="18"
        :max="32"
        size="small"
        step-strictly
        :step="1"
      ></el-input-number>
    </el-form-item>
    <el-form-item label="最大分值">
      <el-input-number
        v-model="store.max"
        :min="3"
        :max="10"
        size="small"
        step-strictly
        :step="1"
        @change="changeMax"
      ></el-input-number>
    </el-form-item>
    <el-form-item label="默认分值">
      <el-input-number v-model="store.default" :min="1" :max="store.max" size="small"></el-input-number>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.showText">显示分值说明</el-checkbox>
    </el-form-item>
    <el-form-item label="分值说明" v-if="store.showText">
      <el-input
        v-for="(item,index) in store.texts"
        :key="index"
        size="small"
        class="mb10"
        v-model="store.texts[index]"
      >
        <template slot="prepend">{{index+1}}分</template>
      </el-input>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  watch: {
    'store.max': {
      handler(val) {
        if (val === 3) {
          this.store.texts = ['极差', '一般', '满意'];
        } else {
          let remain = val - 3;
          let arr = [];
          for (let i = 0; i < remain; i++) {
            arr.push('');
          }
          this.store.texts = ['极差', '一般', '满意'].concat(arr);
        }
      },
    },
  },
  computed: {},
  components: {},
  data() {
    return {
      iconOptions: ['el-icon-star-on'],
    };
  },
  methods: {
    changeMax() {
      console.log(this.store.max);
      if (this.store.max == null) {
        this.store.max = this.store.min;
      }
    },
  },
  mounted() {},
};
</script>

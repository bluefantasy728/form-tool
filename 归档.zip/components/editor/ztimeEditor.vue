<style lang="scss" scoped>
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item label="提示文字">
      <el-input v-model="store.placeholder" size="small"></el-input>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.required">必填</el-checkbox>
      <el-checkbox v-model="store.hide">是否隐藏</el-checkbox>
    </el-form-item>
    <el-form-item label="默认时间">
      <el-select v-model="store.value" size="small" @change="change">
        <el-option label="留空" value="space"></el-option>
        <el-option label="填表当前时间" value="now"></el-option>
        <el-option label="指定时间" value="diy"></el-option>
      </el-select>
      <el-time-picker
        v-model="store.valueDiy"
        clear-icon="none"
        size="small"
        v-show="store.value == 'diy'"
        style="width: 100%;"
      ></el-time-picker>
    </el-form-item>
    <el-form-item label="开始时间">
      <el-time-picker
        class="picker"
        v-model="store.startTime"
        value-format="HH:mm:ss"
        clear-icon="none"
        size="small"
        style="width: 100%;"
        default-value="00:00:00"
        :picker-options="{
          selectableRange: '00:00:00 - ' + store.endTime
        }"
        @change="change1"
      ></el-time-picker>
    </el-form-item>
    <el-form-item label="结束时间">
      <el-time-picker
        class="picker"
        v-model="store.endTime"
        value-format="HH:mm:ss"
        default-value="23:59:59"
        clear-icon="none"
        :picker-options="{
          selectableRange: store.startTime + ' - 23:59:59'
        }"
        size="small"
        style="width: 100%;"
      ></el-time-picker>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  computed: {},
  components: {},
  data() {
    return {};
  },
  methods: {
    change(val) {
      if (val == 'diy') {
        this.store.valueDiy = new Date();
      }
    },
    change1(val) {
      console.log(val);
    },
  },
  mounted() {},
};
</script>

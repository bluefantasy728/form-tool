<style lang="scss" scoped>
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item label="对齐方式">
      <el-radio-group v-model="store.align" size="small">
        <el-radio-button label="left">居左</el-radio-button>
        <el-radio-button label="center">居中</el-radio-button>
        <el-radio-button label="right">居右</el-radio-button>
      </el-radio-group>
    </el-form-item>
    <el-form-item label="字体大小">
      <el-input-number
        v-model="store.fontSize"
        size="small"
        :min="12"
        :max="32"
        :step="1"
        step-strictly
      ></el-input-number>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="isBold">粗体</el-checkbox>
      <el-checkbox v-model="isItalic">斜体</el-checkbox>
    </el-form-item>
    <color-input :color.sync="store.color"/>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  computed: {},
  components: {},
  watch: {
    isBold(val) {
      this.store.fontWeight = val ? 600 : 400;
    },
    isItalic(val) {
      this.store.fontStyle = val ? 'italic' : 'normal';
    },
  },
  data() {
    return {
      isBold: false,
      isItalic: false,
    };
  },
  methods: {},
  mounted() {},
};
</script>

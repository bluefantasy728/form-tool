<style lang="scss" scoped>
.upload-area /deep/ {
  .el-upload,
  .el-upload-dragger {
    width: 100%;
  }
  .el-upload__text {
    font-size: 12px;
  }
}
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.required">必填</el-checkbox>
      <el-checkbox v-model="store.hide">是否隐藏</el-checkbox>
    </el-form-item>
    <el-form-item label="上传图片">
      <el-upload
        class="upload-area"
        drag
        action
        :show-file-list="false"
        :http-request="upload"
        accept="image/jpeg, image/png, image/bmp, image/gif"
      >
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">
          将文件拖到此处，或
          <em>点击上传</em>
          <div class="el-upload__tip" slot="tip">jpg,jpeg,bmp,png格式</div>
        </div>
      </el-upload>
      <drag-input :arr.sync="store.pics"></drag-input>
    </el-form-item>
    <el-form-item label="图标"></el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
import dragInput from '@/components/input/dragInput';
export default {
  mixins: [editor],
  watch: {},
  computed: {
    formId() {
      return this.$route.query.id;
    },
  },
  components: { dragInput },
  data() {
    return {
      iconOptions: ['el-icon-star-on'],
    };
  },
  methods: {
    async upload(file) {
      let uuid = this.mod.uuid;
      try {
        let fd = new FormData();
        fd.append('file', file.file);
        let res = await this.$axios.post(
          `/resource/${this.formId}/${uuid}/1`,
          fd,
        );
        this.store.imgUrl = res.data.imageUrl;
      } catch (err) {}
    },
  },
  mounted() {
    console.log(this.store.pics);
  },
};
</script>

<style lang="scss" scoped>
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item label="提示文字">
      <el-input v-model="store.placeholder" size="small"></el-input>
    </el-form-item>
    <el-form-item label="限制字数">
      <el-input
        v-model.number="store.minlength"
        size="small"
        placeholder="最少字数"
        class="half"
        @keyup.native="positive($event,'store.minlength')"
      ></el-input>
      <el-input
        v-model.number="store.maxlength"
        size="small"
        placeholder="最多字数"
        class="half"
        @keyup.native="positive($event,'store.maxlength')"
      ></el-input>
    </el-form-item>
    <el-form-item label="正则校验">
      <el-select v-model="store.rule" size="small">
        <el-option label="关闭" value=""></el-option>
        <el-option label="数字" value="^[1-9]\d*$"></el-option>
        <el-option label="网址" value="^(http(s)?:\/\/)?(([A-Za-z0-9-~]+)\.)+([A-Za-z0-9-~\/])+$"></el-option>
        <el-option label="qq号" value="^[1-9]([0-9]{5,11})$"></el-option>
        <el-option label="中国身份证" value="^\d{17}[\d|x]|\d{15}$"></el-option>
        <el-option label="中国手机号" value="^(13|14|15|17|18|19)[0-9]{9}$"></el-option>
        <el-option
          label="ip地址"
          value="^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"
        ></el-option>
        <el-option label="自定义" value="diy"></el-option>
      </el-select>
      <el-input
        v-model="store.ruleDiy"
        size="small"
        v-show="store.rule == 'diy'"
        placeholder="例如数字：^[1-9]\d*$"
      ></el-input>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.required">必填</el-checkbox>
      <el-checkbox v-model="store.noRepeat">不允许重复值</el-checkbox>
      <el-checkbox v-model="store.password">密文显示</el-checkbox>
      <el-checkbox v-model="store.hide">是否隐藏</el-checkbox>
      <el-checkbox v-model="store.keyword">是否需要关键词统计</el-checkbox>
    </el-form-item>
    <el-form-item label="宽度">
      <el-radio-group v-model="store.width" size="small">
        <el-radio-button label="50%"></el-radio-button>
        <el-radio-button label="75%"></el-radio-button>
        <el-radio-button label="100%"></el-radio-button>
      </el-radio-group>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  computed: {},
  components: {},
  data() {
    return {};
  },
  methods: {},
  mounted() {},
};
</script>

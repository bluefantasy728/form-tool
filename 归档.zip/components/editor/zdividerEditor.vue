<style lang="scss" scoped>
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>

    <el-form-item label="宽度">
      <el-input-number
        v-model="store.width"
        size="small"
        :min="minWidth"
        :max="maxWidth"
        _change="changeWidth"
      ></el-input-number>
    </el-form-item>

    <color-input :color.sync="store.color"/>
    <el-form-item label="分割线类型">
      <el-radio-group v-model="store.type" size="small" @change="changeStyle">
        <el-radio-button label="dashed">虚线</el-radio-button>
        <el-radio-button label="solid">实线</el-radio-button>
        <el-radio-button label="dotted">点状</el-radio-button>
        <el-radio-button label="double">双线</el-radio-button>
      </el-radio-group>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  computed: {},
  components: {},
  data() {
    return {
      minWidth: 1,
      maxWidth: 10,
    };
  },
  methods: {
    changeStyle(style) {
      switch (style) {
        case 'dashed':
          this.minWidth = 1;
          this.store.width = 1;
          break;
        case 'solid':
          this.minWidth = 1;
          this.store.width = 1;
          break;
        case 'dotted':
          this.minWidth = 2;
          this.store.width = 2;
          break;
        case 'double':
          this.store.width = 3;
          this.minWidth = 3;
          break;
        default:
          break;
      }
    },
  },
  mounted() {},
};
</script>

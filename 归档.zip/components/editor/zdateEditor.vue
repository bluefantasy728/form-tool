<style lang="scss" scoped>
.slide {
  /deep/ {
    .el-input__inner {
      padding-top: 5px;
      padding-bottom: 5px;
    }
  }
}
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item label="提示文字">
      <el-input v-model="store.placeholder" size="small"></el-input>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.required">必填</el-checkbox>
      <el-checkbox v-model="store.hide">是否隐藏</el-checkbox>
    </el-form-item>
    <el-form-item label="默认时间">
      <el-select v-model="store.value" size="small" @change="change">
        <el-option label="留空" value="space"></el-option>
        <el-option label="填表当前时间" value="now"></el-option>
        <el-option label="指定时间" value="diy"></el-option>
      </el-select>
      <el-date-picker
        class="picker"
        v-model="store.valueDiy"
        clear-icon="none"
        size="small"
        v-show="store.value == 'diy'"
        style="width: 100%;"
      ></el-date-picker>
    </el-form-item>
    <el-form-item label="开始时间">
      <el-select v-model="store.startTime" size="small">
        <el-option label="不限制" value=""></el-option>
        <el-option label="填表当前时间" value="now"></el-option>
        <el-option label="指定时间" value="diy"></el-option>
      </el-select>
      <el-date-picker
        class="picker"
        v-model="store.startDiy"
        :picker-options="startDatePicker"
        size="small"
        v-show="store.startTime == 'diy'"
        style="width: 100%;"
      ></el-date-picker>
    </el-form-item>
    <el-form-item label="结束时间">
      <el-select v-model="store.endTime" size="small">
        <el-option label="不限制" value=""></el-option>
        <el-option label="填表当前时间" value="now"></el-option>
        <el-option label="指定时间" value="diy"></el-option>
      </el-select>
      <el-date-picker
        class="picker"
        v-model="store.endDiy"
        :picker-options="endDatePicker"
        size="small"
        v-show="store.endTime == 'diy'"
        style="width: 100%;"
      ></el-date-picker>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  computed: {},
  components: {},
  data() {
    return {
      startDatePicker: this.startDate(),
      endDatePicker: this.endDate(),
    };
  },
  methods: {
    change(val) {
      if (val == 'diy') {
        this.store.valueDiy = new Date();
      }
    },
    startDate() {
      let _this = this;
      return {
        disabledDate(time) {
          if (_this.store && _this.store.endTime == 'now') {
            return time.getTime() > new Date().getTime();
          } else if (
            _this.store &&
            _this.store.endTime == 'diy' &&
            _this.store.endDiy
          ) {
            return time.getTime() > _this.store.endDiy.getTime();
          } else {
            return false;
          }
        },
      };
    },
    endDate() {
      let _this = this;
      return {
        disabledDate(time) {
          if (_this.store && _this.store.startTime == 'now') {
            return time.getTime() < new Date().getTime();
          } else if (
            _this.store &&
            _this.store.startTime == 'diy' &&
            _this.store.startDiy
          ) {
            return time.getTime() < _this.store.startDiy.getTime();
          } else {
            return false;
          }
        },
      };
    },
  },
  mounted() {},
};
</script>

<style lang="scss" scoped>
.upload-demo /deep/ {
  .el-upload,
  .el-upload-dragger {
    width: 100%;
  }
  .el-upload__text {
    font-size: 12px;
  }
}
.img-url /deep/,
.whole-row /deep/ {
  font-size: 12px;
  .el-checkbox__label {
    font-size: 12px;
  }
}
</style>

<template>
  <el-form label-position="top">
    <el-form-item label>
      <el-checkbox v-model="store.isWholeRow" class="whole-row">通栏显示</el-checkbox>
    </el-form-item>
    <el-form-item label="对齐方式" v-if="!store.isWholeRow">
      <el-radio-group v-model="store.align" size="small">
        <el-radio-button label="left">居左</el-radio-button>
        <el-radio-button label="center">居中</el-radio-button>
        <el-radio-button label="right">居右</el-radio-button>
      </el-radio-group>
    </el-form-item>
    <el-form-item label="上传图片">
      <el-upload
        class="upload-demo"
        drag
        action
        :show-file-list="false"
        :http-request="upload"
        accept="image/jpeg, image/png, image/bmp, image/gif"
      >
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">
          将文件拖到此处，或
          <em>点击上传</em>
          <div class="el-upload__tip" slot="tip">jpg,jpeg,bmp,png格式</div>
        </div>
      </el-upload>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.requireUrl" class="img-url">点击图片跳转页面</el-checkbox>
      <el-input placeholder="请输入跳转链接" size="small" v-model="store.url" v-if="store.requireUrl"></el-input>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  computed: {
    formId() {
      return this.$route.query.id;
    },
  },
  components: {},
  data() {
    return {};
  },
  methods: {
    async upload(file) {
      let uuid = this.mod.uuid;
      try {
        let fd = new FormData();
        fd.append('file', file.file);
        let res = await this.$axios.post(
          `/resource/${this.formId}/${uuid}/1`,
          fd,
        );
        this.store.imgUrl = res.data.imageUrl;
      } catch (err) {}
    },
    successFn(response, file, fileList) {
      const windowURL = window.URL || window.webkitURL;
      const dataURL = windowURL.createObjectURL(file.raw);
      this.store.imgUrl = dataURL;
    },
  },
  mounted() {},
};
</script>

<style lang="scss" scoped>
.format-checkbox /deep/ {
  .el-form-item__content {
    display: flex;
    flex-wrap: wrap;
  }
  .el-checkbox {
    margin-top: 0 !important;
    margin-right: 20px !important;
  }
}
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.required">必填</el-checkbox>
      <el-checkbox v-model="store.hide">是否隐藏</el-checkbox>
      <el-checkbox v-model="store.isMultiple">允许上传多张图片</el-checkbox>
    </el-form-item>
    <el-form-item label="图片个数限制" v-if="store.isMultiple">
      <el-input-number v-model="store.limitQty" :min="2" size="small"></el-input-number>
    </el-form-item>
    <el-form-item class="format-checkbox" label="限制图片类型">
      <el-checkbox v-model="format['image/jpeg']">jpeg/jpg</el-checkbox>
      <el-checkbox v-model="format['image/png']">png</el-checkbox>
      <el-checkbox v-model="format['image/bmp']">bmp</el-checkbox>
      <el-checkbox v-model="format['image/gif']">gif</el-checkbox>
    </el-form-item>
    <el-form-item label="图片大小限制（单位：kb）">
      <el-input v-model="store.limitSize" size="small"></el-input>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
const formatArray = ['image/jpeg', 'image/png', 'image/bmp', 'image/gif'];
export default {
  mixins: [editor],
  computed: {},
  components: {},
  watch: {
    format: {
      handler: function(newVal, oldVal) {
        console.log(newVal);
        let formatArr = [];
        let acceptFormatArr = [];
        for (let k in newVal) {
          if (newVal[k]) {
            formatArr.push(k.split('/')[1]);
            acceptFormatArr.push(k);
          }
        }
        this.store.acceptImgFormat = acceptFormatArr.join(',');
      },
      deep: true,
    },
    'store.acceptImgFormat': {
      handler(val, oldVal) {},
      deep: true,
    },
  },
  data() {
    return {
      format: {
        'image/jpeg': false,
        'image/png': false,
        'image/bmp': false,
        'image/gif': false,
      },
    };
  },
  methods: {
    // initFormat() {
    //   let obj = {};
    //   formatArray.forEach(item => {
    //     obj[item] = true;
    //   });
    //   this.format = JSON.parse(JSON.stringify(obj));
    // },
  },
  mounted() {
    // this.initFormat();
    // this.store.format = formatArray;
  },
};
</script>

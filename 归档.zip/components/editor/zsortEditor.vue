<style lang="scss" scoped>
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item label="提示文字">
      <el-input v-model="store.placeholder" size="small"></el-input>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.required">必填</el-checkbox>
      <el-checkbox v-model="store.hide">是否隐藏</el-checkbox>
    </el-form-item>
    <el-form-item label="展示列表项最小个数">
      <el-input-number v-model="store.min" :min="1" :max="store.max" size="small"></el-input-number>
    </el-form-item>
    <el-form-item label="展示列表项最大个数">
      <el-input-number v-model="store.max" :min="1" :max="store.max" size="small"></el-input-number>
    </el-form-item>
    <el-form-item label="选项">
      <array-input v-model="store.options" type="multi"></array-input>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  watch: {},
  computed: {},
  components: {},
  data() {
    return {};
  },
  methods: {},
  mounted() {},
};
</script>

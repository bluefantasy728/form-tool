<style lang="scss" scoped>
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item label="提示文字">
      <el-input v-model="store.placeholder" size="small"></el-input>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.required">必填</el-checkbox>
      <el-checkbox v-model="store.hide">是否隐藏</el-checkbox>
    </el-form-item>
    <el-form-item label="选项">
      <array-input v-model="store.options" size="small"></array-input>
    </el-form-item>
    <el-form-item label="宽度">
      <el-radio-group v-model="store.width" size="small">
        <el-radio-button label="50%"></el-radio-button>
        <el-radio-button label="75%"></el-radio-button>
        <el-radio-button label="100%"></el-radio-button>
      </el-radio-group>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  computed: {},
  components: {},
  data() {
    return {};
  },
  methods: {},
  mounted() {},
};
</script>

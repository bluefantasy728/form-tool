<style lang="scss" scoped>
</style>

<template>
  <el-form label-position="top">
    <el-form-item label="标题">
      <el-input v-model="store.title" size="small"></el-input>
    </el-form-item>
    <el-form-item label="描述">
      <el-input v-model="store.desc" size="small"></el-input>
    </el-form-item>
    <el-form-item>
      <el-checkbox v-model="store.required">必填</el-checkbox>
      <el-checkbox v-model="store.hide">是否隐藏</el-checkbox>
    </el-form-item>
    <el-form-item label="最少选择">
      <el-input-number v-model="store.min" size="small" :min="0" :max="max"></el-input-number>
    </el-form-item>
    <el-form-item label="最多选择">
      <el-input-number v-model="store.max" size="small" :min="0" :max="max"></el-input-number>
    </el-form-item>
    <el-form-item label="选项">
      <el-checkbox v-model="store.other" class="mb10">添加“其他”选项</el-checkbox>
      <array-input v-model="store.options" type="multi"></array-input>
    </el-form-item>
  </el-form>
</template>

<script>
import editor from '@/mixin/editor';
export default {
  mixins: [editor],
  computed: {
    max() {
      if (!this.store.options) {
        return 0;
      }
      if (this.store.other) {
        return this.store.options.length + 1;
      } else {
        return this.store.options.length;
      }
    },
  },
  components: {},
  data() {
    return {
      min: 1,
    };
  },
  methods: {},
  mounted() {},
};
</script>

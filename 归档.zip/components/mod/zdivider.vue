<style lang="scss" scoped>
</style>

<template>
  <div class="mod padding" v-show="!store.hide" :style="{
    textAlign:store.align
  }">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <div>
      <div :style="{borderBottom:lineStyle}"></div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['store'],
  components: {},
  computed: {
    lineStyle() {
      return `${this.store.width}px ${this.store.type} ${this.store.color}`;
    },
  },
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>

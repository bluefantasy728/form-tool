<style lang="scss" scoped>
</style>

<template>
  <div class="mod padding" v-show="!store.hide">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>

    <el-radio
      v-model="value"
      :label="item.label"
      v-for="(item,index) in store.options"
      :key="index"
      @change="validate"
    >{{item.label}}</el-radio>
    <el-radio v-model="value" @change="validate" label="other" v-if="store.other">其他</el-radio>
    <el-input v-model="otherValue" @change="validate" class="mt10" v-if="value == 'other'"></el-input>
  </div>
</template>

<script>
export default {
  props: ['store'],
  computed: {},
  watch: {
    'store.options'(value) {
      let item = value.find(item => {
        return item.selected;
      });
      if (item) {
        this.value = item.label;
      } else {
        this.value = '';
      }
    },
  },
  data() {
    return {
      value: '',
      otherValue: '',
    };
  },
  methods: {
    validate() {
      let model = {
        value: this.value != 'other' ? this.value : this.otherValue,
        validated: true,
        message: '',
      };
      if (this.store.required && !this.value.length) {
        model.validated = false;
        model.message = `"${this.store.title}"必填`;
      }
      if (this.value.includes('other') && !this.otherValue) {
        model.validated = false;
        model.message = `"${this.store.title}"其他必填`;
      }
      this.$emit('input', model);
    },
  },
  mounted() {
    this.store.options.forEach((item, index) => {
      if (item.selected) {
        this.value = item.label;
      }
    });

    this.validate();
  },
};
</script>

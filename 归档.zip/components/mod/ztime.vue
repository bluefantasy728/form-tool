<style lang="scss" scoped>
</style>

<template>
  <div class="mod padding" v-show="!store.hide">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div class="label" :class="{required:store.required}">{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <el-time-picker
      v-model="value"
      :placeholder="store.placeholder"
      :editable="false"
      @change="change"
      :picker-options="{
        selectableRange: store.startTime + ' - ' + store.endTime
      }"
    ></el-time-picker>
  </div>
</template>

<script>
export default {
  props: ['store'],
  components: {},
  beforeRouteEnter(to, from, next) {
    next();
  },
  computed: {},
  watch: {
    store(val) {
      if (val.value == 'diy') {
        this.value = val.valueDiy;
      } else if (val.value == 'now') {
        this.value = new Date();
      } else {
        this.value = '';
      }
    },
  },
  data() {
    return {
      value: '',
    };
  },
  mounted() {
    if (this.store.value == 'diy') {
      this.value = this.store.valueDiy;
    } else if (this.store.value == 'now') {
      this.value = new Date();
    }
    this.validate();
  },
  methods: {
    change(value) {
      this.validate();
    },
    validate() {
      let model = {
        value: this.value
          ? this.$momentFormat(this.value, 'hh:mm:ss')
          : this.value,
        validated: true,
        message: '',
      };
      if (this.store.required && !this.value) {
        console.log(this.value);
        model.validated = false;
        model.message = `"${this.store.title}"必填`;
      }
      this.$emit('input', model);
    },
  },
};
</script>

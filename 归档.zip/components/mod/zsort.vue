<style lang="scss" scoped>
.sort-edit,
.sort-display {
  width: 49%;
  border: 1px dashed #e0e0e0;
  padding: 15px 10px;
  min-height: 50px;
}
.display-item {
  cursor: pointer;
  display: flex;
  margin-bottom: 10px;
  padding: 10px 0;
  border: 1px solid #e0e0e0;
  &:nth-last-of-type(1) {
    margin-bottom: 0;
  }
  .sort-index {
    flex-shrink: 0;
    width: 20px;
    height: 20px;
    line-height: 20px;
    background: #000;
    color: #fff;
    text-align: center;
    margin-left: 10px;
  }
  .sort-label {
    font-size: 12px;
    flex: 1;
    padding-left: 10px;
    line-height: 18px;
  }
}
</style>
<template>
  <div class="mod padding" v-show="!store.hide">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <div class="sort-wrapper clearfix">
      <div class="sort-display fl">
        <draggable
          :list="value.left"
          group="sort"
          draggable=".display-item"
          style="min-height:70px;"
          @change="changeLeft"
        >
          <div class="display-item" v-for="(item,index) in value.left" :key="index">
            <p class="sort-index">{{index+1}}</p>
            <p class="sort-label">{{item.label}}</p>
          </div>
        </draggable>
      </div>
      <div class="sort-edit fr">
        <draggable :list="value.right" group="sort" draggable=".display-item">
          <div class="display-item" v-for="(item,index) in value.right" :key="index">
            <p class="sort-label">{{item.label}}</p>
          </div>
        </draggable>
      </div>
    </div>
  </div>
</template>
<script>
import draggable from 'vuedraggable';
import _ from 'lodash';
export default {
  props: ['store'],
  components: {
    draggable,
  },
  computed: {},
  watch: {
    'store.options': {
      handler: function(val, oldVal) {
        console.log(val);
        if (val.length === oldVal.length) {
          // 是否有任意一个selected的，如果有，把它放到sortedOptions里，并把selected变成false
          let indexSelected = val.findIndex(item => item.selected);
          console.log(indexSelected);
          // if (indexSelected >= 0) {
          this.value.left = this.store.options.filter(item => item.selected);
          this.value.right = this.store.options.filter(item => !item.selected);
          // }
        }
      },
      deep: true,
    },
  },
  data() {
    return {
      value: {
        left: [],
        right: this.store.options,
      },
      otherValue: '',
    };
  },
  methods: {
    validate() {
      let value = this.value.left.map((item, index) => {
        return { value: item.label, index };
      });
      let model = {
        value,
        validated: true,
        message: '',
      };
      if (
        this.store.required &&
        (!this.value.left || this.value.left.length === 0)
      ) {
        model.validated = false;
        model.message = `"${this.store.title}"至少要有一条选项`;
      }
      this.$emit('input', model);
    },
    changeLeft() {
      this.validate();
    },
  },
  mounted() {
    this.value.left = this.store.options.filter(item => item.selected);
    this.value.right = this.store.options.filter(item => !item.selected);
    this.validate();
  },
};
</script>

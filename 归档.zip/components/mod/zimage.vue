<style lang="scss" scoped>
.h180 {
  height: 180px;
}
.placeholder {
  position: relative;
  width: 100%;
  height: 100%;
  font-size: 92px;
  background: #eee;
  color: #ccc;
}
.imgLink {
  display: inline-block;
  vertical-align: top;
  height: 100%;
  max-width: 100%;
  .img {
    display: block;
    width: 100%;
  }
}
.whole-row {
  padding: 15px 0 !important;
  .imgLink {
    width: 100% !important;
  }
}
</style>

<template>
  <div
    class="mod padding"
    :class="{'whole-row':store.isWholeRow}"
    v-show="!store.hide"
    :style="{
    textAlign:store.align
  }"
  >
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <div class="wrapper" :class="{'h180':!store.imgUrl}">
      <div class="placeholder" v-if="!store.imgUrl">
        <i class="el-icon-picture-outline center"></i>
      </div>
      <a v-if="store.imgUrl && store.requireUrl" class="imgLink" :href="store.url">
        <img class="img" :src="store.imgUrl" alt>
      </a>
      <a v-if="store.imgUrl && !store.requireUrl" class="imgLink" href="javascript:;">
        <img class="img" :src="store.imgUrl" alt>
      </a>
    </div>
  </div>
</template>

<script>
export default {
  props: ['store'],
  components: {},
  computed: {},
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>

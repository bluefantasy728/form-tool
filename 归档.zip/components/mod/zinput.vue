<style lang="scss" scoped>
</style>

<template>
  <div class="mod padding" v-show="!store.hide">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <el-input
      :placeholder="store.placeholder"
      :maxlength="store.maxlength"
      :type="store.password?'password':'text'"
      :style="{
        width:store.width
      }"
      v-model="value"
      @change="validate"
    ></el-input>
  </div>
</template>

<script>
export default {
  props: ['store'],
  components: {},
  computed: {},
  data() {
    return {
      value: '',
    };
  },
  methods: {
    validate() {
      let model = {
        value: this.value,
        validated: true,
        message: '',
      };
      if (this.store.required && !this.value) {
        model.validated = false;
        model.message = `"${this.store.title}"必填`;
      } else if (this.value.length < this.store.minlength) {
        model.validated = false;
        model.message = `"${this.store.title}"最少${this.store.minlength}字`;
      } else if (this.value && this.store.rule && !this.test()) {
        model.validated = false;
        model.message = `"${this.store.title}"格式不正确`;
      }
      this.$emit('input', model);
    },
    test() {
      console.log(this.store.rule);
      if (this.store.rule == 'diy') {
        let exec = new RegExp(this.store.ruleDiy);
        return exec.test(this.value);
      } else {
        let exec = new RegExp(this.store.rule);
        return exec.test(this.value);
      }
    },
  },
  mounted() {
    this.validate();
  },
};
</script>

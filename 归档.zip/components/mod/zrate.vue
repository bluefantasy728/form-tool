<style lang="scss" scoped>
.mod /deep/ {
  .el-rate__icon,
  .el-rate__item {
    font-size: inherit;
  }
  .el-rate__text {
    display: block;
    margin-top: 8px;
    font-size: 13px;
    color: #999 !important;
  }
  .rate-wrapper {
    display: inline-block;
    height: 50px;
  }
}
</style>
<template>
  <div class="mod padding" v-show="!store.hide">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <div class="rate-wrapper">
      <el-rate
        v-model="value"
        :max="this.store.max"
        :show-text="store.showText"
        :texts="store.texts"
        :style="{fontSize:`${store.fontSize}px`}"
        @change="validate()"
      ></el-rate>
    </div>
  </div>
</template>
<script>
export default {
  props: ['store'],
  components: {},
  computed: {},
  watch: {
    'store.default': {
      handler: function(val) {
        this.value = val;
      },
    },
  },
  data() {
    return {
      value: this.store.default,
    };
  },
  methods: {
    validate() {
      let value = this.value + '';
      console.log(value);
      let model = {
        value,
        validated: true,
        message: '',
      };
      if (this.store.required && !this.value) {
        model.validated = false;
        model.message = `"${this.store.title}"必填`;
      }
      this.$emit('input', model);
    },
  },
  mounted() {
    this.validate();
  },
};
</script>

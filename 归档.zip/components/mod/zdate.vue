<style lang="scss" scoped>
</style>

<template>
  <div class="mod padding" v-show="!store.hide">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div class="label" :class="{required:store.required}">{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <el-date-picker
      :placeholder="store.placeholder"
      v-model="value"
      @change="change"
      :editable="false"
      :picker-options="options"
    ></el-date-picker>
  </div>
</template>

<script>
export default {
  props: ['store'],
  components: {},
  beforeRouteEnter(to, from, next) {
    next();
  },
  watch: {
    store(val) {
      if (val.value == 'diy') {
        this.value = val.valueDiy;
      } else if (val.value == 'now') {
        this.value = new Date();
      } else {
        this.value = '';
      }
      if (val.startTime == 'diy') {
        this.start = val.startDiy;
      } else if (val.startTime == 'now') {
        this.start = new Date();
      }
      if (val.endTime == 'diy') {
        this.end = val.endDiy;
      } else if (val.endTime == 'now') {
        this.end = new Date();
      }
    },
  },
  computed: {},
  data() {
    return {
      value: '',
      start: '',
      end: '',
      options: this.filters(),
    };
  },
  mounted() {
    if (this.store.value == 'diy') {
      this.value = this.store.valueDiy;
    } else if (this.store.value == 'now') {
      this.value = new Date();
    }
    this.validate();
    if (this.store.startTime == 'diy') {
      this.start = new Date(this.store.startDiy);
    } else if (this.store.startTime == 'now') {
      this.start = new Date();
    }
    if (this.store.endTime == 'diy') {
      this.end = new Date(this.store.endDiy);
    } else if (this.store.endTime == 'now') {
      this.end = new Date();
    }
  },
  methods: {
    change() {
      this.validate();
    },
    validate() {
      let model = {
        value: this.value
          ? this.$momentFormat(this.value, 'YYYY-MM-DD')
          : this.value,
        validated: true,
        message: '',
      };
      if (this.store.required && !this.value) {
        model.validated = false;
        model.message = `"${this.store.title}"必填`;
      }
      this.$emit('input', model);
    },
    filters() {
      let _this = this;
      return {
        disabledDate(time) {
          if (_this.start && _this.end) {
            return (
              time.getTime() < _this.start.getTime() ||
              time.getTime() > _this.end.getTime()
            );
          } else if (_this.start && !_this.end) {
            return time.getTime() < _this.start.getTime();
          } else if (!_this.start && _this.end) {
            return time.getTime() > _this.end.getTime();
          } else {
            return false;
          }
        },
      };
    },
  },
};
</script>

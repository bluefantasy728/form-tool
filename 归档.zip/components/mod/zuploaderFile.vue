<style lang="scss" scoped>
.mod /deep/ {
  .el-upload-dragger,
  .el-upload {
    width: 100%;
  }
}
</style>

<template>
  <div class="mod padding" v-show="!store.hide" :style="{
    textAlign:store.align
  }">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <div>
      <el-upload
        class="upload-demo"
        drag
        action=""
        __list-type="picture"
        :accept="store.acceptFormatString"
        :multiple="store.isMultiple"
        :limit="store.limitQty"
        :http-request="uploadFn"
        :file-list="value"
        :before-upload="beforeFn"
        :on-exceed="exceedFn"
        :on-change="change"
        :on-remove="change"
      >
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">
          将文件拖到此处，或
          <em>点击上传</em>
          <div class="el-upload__tip" slot="tip">{{format}}格式，不超过{{store.limitSize}}kb</div>
        </div>
      </el-upload>
    </div>
  </div>
</template>

<script>
export default {
  props: ['store'],
  components: {},
  watch: {},
  computed: {
    format() {
      return this.store.acceptFileFormat.trim() === ''
        ? '任意'
        : this.store.acceptFileFormat;
    },
  },
  data() {
    return {
      value: [],
    };
  },
  mounted() {
    this.validate();
  },
  methods: {
    validate() {
      let model = {
        value: this.value.map(item => {
          return {
            name: item.name,
            url: item.response,
          };
        }),
        validated: true,
        message: '',
      };
      if (this.store.required && this.value.length === 0) {
        model.validated = false;
        model.message = `"${this.store.title}"必填`;
      }
      this.$emit('input', model);
    },
    change(file, fileList) {
      this.value = fileList;
      this.validate();
    },
    beforeFn(file) {
      console.log(file);
      const expandName = file.name.split('.')[1];
      const acceptFormatArr = this.store.acceptFileFormat.split(',');
      if (
        this.store.acceptFileFormat.trim() !== '' &&
        !acceptFormatArr.includes(expandName)
      ) {
        this.$message.error(
          `文件格式必须是${this.store.acceptFileFormat}其中一个`,
        );
        return false;
      }
      if (file.size > this.store.limitSize * 1024) {
        this.$message.error(`文件大小不能超过${this.store.limitSize}kb`);
        return false;
      }
      return true;
    },
    uploadFn(file) {
      console.log(file);
    },
    successFn(response, file, fileList) {
      const windowURL = window.URL || window.webkitURL;
      this.store.fileList = fileList.map(item => {
        return {
          name: item.name,
          url: windowURL.createObjectURL(item.raw),
        };
      });
      this.value = JSON.parse(JSON.stringify(this.store.fileList));
    },
    async uploadFn(file) {
      let uuid = this.uuid;
      let formId = this.$route.params.id;
      try {
        let fd = new FormData();
        fd.append('file', file.file);
        let res = await this.$axios.post(`/resource/${formId}/${uuid}/2`, fd);
        return res.data.imageUrl;
      } catch (err) {}
    },
    exceedFn(files, fileList) {
      this.$message.error(`上传文件的个数不能超过${this.store.limitQty}`);
    },
  },
};
</script>

<style lang="scss" scoped>
.currency-input /deep/ {
  .el-input-group__prepend {
    width: 64px;
    text-align: center;
    padding: 0;
  }
}
</style>

<template>
  <div class="mod padding" v-show="!store.hide" :style="{
    textAlign:store.align
  }">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <div>
      <el-input
        class="currency-input"
        v-model="value"
        @change="change"
        :placeholder="store.placeholder"
      >
        <template slot="prepend">{{currency}}</template>
      </el-input>
    </div>
  </div>
</template>

<script>
export default {
  props: ['store'],
  components: {},
  computed: {
    currency() {
      return this.currencyArr.find(item => item.value === this.store.unit).name;
    },
  },
  data() {
    return {
      value: '',
      currencyArr: [
        {
          label: '¥ 人民币',
          value: 'RMB',
          name: '人民币',
        },
        {
          label: 'JP¥ 日元',
          value: 'JPY',
          name: '日元',
        },
        {
          label: '$ 美元',
          value: 'USD',
          name: '美元',
        },
        {
          label: '€ 欧元',
          value: 'EUR',
          name: '欧元',
        },
      ],
    };
  },
  mounted() {
    this.validate();
  },
  methods: {
    validate() {
      let model = {
        value: {
          unit: this.currency,
          value: this.value,
        },
        validated: true,
        message: '',
      };
      if (this.store.required && !this.value) {
        model.validated = false;
        model.message = `"${this.store.title}"必填`;
      } else if (this.store.min && Number(this.value) < this.store.min) {
        model.validated = false;
        model.message = `${this.store.title}的${this.currency}值不能小于${
          this.store.min
        }`;
      } else if (this.store.max && Number(this.value) > this.store.max) {
        model.validated = false;
        model.message = `${this.store.title}的${this.currency}值不能大于${
          this.store.max
        }`;
      }
      this.$emit('input', model);
    },
    change() {
      this.validate();
    },
  },
};
</script>

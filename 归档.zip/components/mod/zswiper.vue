<style lang="scss" scoped>
/deep/ {
  .swiper-container {
    width: 100%;
    height: 400px;
    .swiper-wrapper {
      height: 100%;
    }
    .swiper-slide {
      overflow: hidden;
    }
    .swiper-img {
      display: block;
      object-fit: cover;
      object-position: center center;
      height: 100%;
      width: 100%;
    }
  }
}
</style>
<template>
  <div class="mod padding" v-show="!store.hide">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <no-ssr>
      <swiper :options="swiperOption" ref="mySwiper">
        <!-- slides -->

        <swiper-slide v-for="(item,index) in pics" :key="index">
          <img class="swiper-img" :src="item">
        </swiper-slide>
        <!-- Optional controls -->
        <!-- <div class="swiper-pagination" slot="pagination"></div>
        <div class="swiper-button-prev" slot="button-prev"></div>
        <div class="swiper-button-next" slot="button-next"></div>
        <div class="swiper-scrollbar" slot="scrollbar"></div>-->
      </swiper>
    </no-ssr>
  </div>
</template>
<script>
// import { swiper, swiperSlide } from 'vue-awesome-swiper';
export default {
  props: ['store'],
  components: {},
  computed: {
    // swiper() {
    //   return this.$refs.mySwiper.swiper;
    // },
  },
  watch: {},
  data() {
    return {
      value: '',
      pics: [
        'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2831960734,63197009&fm=26&gp=0.jpg',
        'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=2106538132,4174177087&fm=26&gp=0.jpg',
        'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1287814793,457485829&fm=26&gp=0.jpg',
        'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3156671389,2646079670&fm=26&gp=0.jpg',
      ],
      swiperOption: {
        loop: true,
        slidesPerView: 'auto',
        centeredSlides: true,
        spaceBetween: 30,
        pagination: {
          el: '.swiper-pagination',
          dynamicBullets: true,
        },
        on: {
          slideChange() {
            console.log('onSlideChangeEnd', this);
          },
          tap() {
            console.log('onTap', this);
          },
        },
      },
    };
  },
  methods: {
    validate() {
      let value = this.value;
      console.log(value);
      let model = {
        value,
        validated: true,
        message: '',
      };
      if (this.store.required && !this.value) {
        model.validated = false;
        model.message = `"${this.store.title}"必填`;
      }
      this.$emit('input', model);
    },
  },
  mounted() {
    this.validate();
  },
};
</script>

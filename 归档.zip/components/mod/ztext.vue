<style lang="scss" scoped>
</style>

<template>
  <div class="mod padding" v-show="!store.hide" :style="{
    textAlign:store.align
  }">
    <div v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
        :style="{color:store.color,fontSize:store.fontSize+'px',fontWeight:store.fontWeight,fontStyle:store.fontStyle,lineHeight:store.fontSize+2+'px'
  }"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['store'],
  components: {},
  computed: {},
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>

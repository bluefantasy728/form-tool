<style lang="scss" scoped>
</style>

<template>
  <div class="mod padding" v-show="!store.hide">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>

    <el-checkbox-group v-model="value" @change="validate" :min="store.min" :max="store.max">
      <el-checkbox
        :label="item.label"
        v-for="(item,index) in store.options"
        :key="index"
      >{{item.label}}</el-checkbox>
      <el-checkbox label="other" v-if="store.other" @change="validate">其他</el-checkbox>
      <el-input v-model="otherValue" @change="validate" class="mt10" v-if="value.includes('other')"></el-input>
    </el-checkbox-group>
  </div>
</template>

<script>
export default {
  props: ['store'],
  computed: {},
  watch: {
    'store.options'(value) {
      let res = value.filter(item => {
        return item.selected;
      });
      if (res.length) {
        this.value = res.map(item => {
          return item.label;
        });
      } else {
        this.value = [];
      }
    },
  },
  data() {
    return {
      value: [],
      otherValue: '',
    };
  },
  methods: {
    validate() {
      let value = [];
      if (this.value.includes('other')) {
        value = [...this.value, this.otherValue];
      } else {
        value = this.value;
      }
      let model = {
        value,
        validated: true,
        message: '',
      };
      if (this.store.required && !this.value.length) {
        model.validated = false;
        model.message = `"${this.store.title}"必填`;
      }
      if (this.value.includes('other') && !this.otherValue) {
        model.validated = false;
        model.message = `"${this.store.title}"其他必填`;
      }
      this.$emit('input', model);
    },
  },
  mounted() {
    this.store.options.forEach((item, index) => {
      if (item.selected) {
        this.value.push(item.label);
      }
    });

    this.validate();
  },
};
</script>

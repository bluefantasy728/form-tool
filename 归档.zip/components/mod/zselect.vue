<style lang="scss" scoped>
</style>

<template>
  <div class="mod padding" v-show="!store.hide">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <el-select
      :placeholder="store.placeholder"
      v-model="value"
      :style="{
        width:store.width
      }"
      @change="validate"
    >
      <el-option
        v-for="(item,index) in store.options"
        :key="index"
        :label="item.label || ' '"
        :value="item.label"
      ></el-option>
    </el-select>
  </div>
</template>

<script>
export default {
  props: ['store'],
  computed: {},
  watch: {
    'store.options'(value) {
      let item = value.find(item => {
        return item.selected;
      });
      if (item) {
        this.value = item.label;
      } else {
        this.value = '';
      }
    },
  },
  data() {
    return {
      value: '',
    };
  },
  methods: {
    validate() {
      let model = {
        value: this.value,
        validated: true,
        message: '',
      };
      if (this.store.required && !this.value) {
        model.validated = false;
        model.message = `"${this.store.title}"必填`;
      }
      this.$emit('input', model);
    },
  },
  mounted() {
    this.store.options.forEach((item, index) => {
      if (item.selected) {
        this.value = item.label;
      }
    });

    this.validate();
  },
};
</script>

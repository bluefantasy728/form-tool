<style lang="scss" scoped>
</style>

<template>
  <div class="mod padding" v-show="!store.hide">
    <div class="mb10" v-show="store.title || store.desc || store.required">
      <div
        class="label"
        :class="{required:store.required}"
        v-show="store.title || store.required"
      >{{store.title}}</div>
      <div class="desc">{{store.desc}}</div>
    </div>
    <el-input
      :placeholder="store.placeholder"
      :maxlength="store.maxlength"
      type="textarea"
      :rows="store.rows"
      resize="none"
      :style="{
        width:store.width
      }"
      v-model="value"
      @change="change"
    ></el-input>
  </div>
</template>

<script>
export default {
  props: ['store'],
  components: {},
  computed: {},
  data() {
    return {
      value: '',
    };
  },
  methods: {
    validate() {
      let model = {
        value: this.value,
        validated: true,
        message: '',
      };
      if (this.store.required && !this.value) {
        model.validated = false;
        model.message = `"${this.store.title}"必填`;
      }
      this.$emit('input', model);
    },
    change() {
      this.validate();
    },
  },
  mounted() {
    this.validate();
  },
};
</script>

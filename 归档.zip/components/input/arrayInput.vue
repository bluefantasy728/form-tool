<style lang="scss" scoped>
/deep/ {
  .el-input-group__append,
  .el-input-group__prepend {
    padding: 0 5px;
  }
  .el-input-group__prepend .el-button {
    margin: 0;
    padding: 0;
  }
  .el-input-group__prepend .el-button + .el-button {
    border-left: 1px solid #ccc;
    border-radius: 0;
    padding-left: 5px;
    color: #ccc;
    font-size: 12px;
  }
  .active {
    color: #000 !important;
  }
}
</style>

<template>
  <div>
    <draggable v-model="options" :group="{ name: 'arrayInput' }" handle=".el-icon-rank">
      <el-input
        v-model="item.label"
        size="small"
        class="mb10"
        v-for="(item, index) in options"
        :key="index"
      >
        <template slot="prepend">
          <el-button icon="el-icon-rank"></el-button>
          <el-button @click="set(item,index)" :class="{active:item.selected}">默认</el-button>
        </template>

        <el-popover
          slot="append"
          placement="top"
          width="auto"
          trigger="manual"
          content="最少保留一项"
          popper-class="error-tip"
          v-model="visible"
          v-if="!index"
        >
          <el-button slot="reference" icon="el-icon-delete" @click="del(index)"></el-button>
        </el-popover>
        <el-button slot="append" icon="el-icon-delete" @click="del(index)" v-else></el-button>
      </el-input>
    </draggable>
    <div class="alignc">
      <el-button type="primary" round @click="add" size="small">添加</el-button>
    </div>
  </div>
</template>

<script>
import draggable from 'vuedraggable';

export default {
  props: {
    value: {
      type: Array,
      default() {
        return [];
      },
    },
    type: null, //multi
  },
  components: {
    draggable,
  },
  beforeRouteEnter(to, from, next) {
    next();
  },
  computed: {},
  data() {
    return {
      visible: false,
      options: [],
      timer: null,
    };
  },
  mounted() {},
  watch: {
    value() {
      this.options = this.value;
    },
    options: {
      handler() {
        this.$emit('input', this.options);
      },
      deep: true,
    },
  },
  methods: {
    set(item, index) {
      let state = item.selected;
      if (this.type != 'multi') {
        this.options.map(v => {
          v.selected = false;
        });
      }
      item.selected = !state;
    },
    del(index) {
      if (this.options.length <= 1) {
        this.visible = true;
        clearTimeout(this.timer);
        this.timer = setTimeout(() => {
          this.visible = false;
        }, 2000);
        return;
      }
      this.options.splice(index, 1);
    },
    add() {
      this.options.push({
        label: '选项' + (this.options.length + 1),
        selected: false,
      });
    },
  },
};
</script>

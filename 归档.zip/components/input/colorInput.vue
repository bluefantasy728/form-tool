<style lang="scss" scoped>
/deep/ {
  .el-color-picker {
    width: 26px;
    height: 26px;
    border: 1px solid #c0c4cc;
    overflow: hidden;
    .el-color-picker__trigger {
      width: 26px;
      height: 26px;
      padding: 0;
      border: 0;
      .el-color-picker__color {
        width: 26px;
        height: 26px;
        border: 0;
      }
    }
  }
}
.color-options {
  display: flex;
  flex-wrap: wrap;
  .color-block {
    width: 28px;
    height: 28px;
    flex-shrink: 0;
    margin: 0 3px 5px 0;
    cursor: pointer;
  }
}
</style>

<template>
  <el-form-item label="选择颜色">
    <div>
      <el-color-picker
        v-model="currentColor"
        size="small"
        :predefine="colorOptions"
        @change="changeColor"
      ></el-color-picker>
    </div>
    <!-- <div class="color-options">
      <div
        class="color-block"
        v-for="(item,index) in colorOptions"
        :key="index"
        :style="{backgroundColor:item}"
        @click="changeColor(item)"
      ></div>
    </div>-->
  </el-form-item>
</template>

<script>
export default {
  props: ['color'],
  components: {},
  beforeRouteEnter(to, from, next) {
    next();
  },
  computed: {},
  data() {
    return {
      colorOptions: [
        '#000',
        '#0000ff',
        '#ff0000',
        '#ffff00',
        '#008000',
        '#ffa500',
        '#808080',
      ],
    };
  },

  computed: {
    currentColor: {
      get: function() {
        return this.color;
      },
      set: function(val) {
        this.$emit('update:color', val);
      },
    },
  },
  mounted() {},
  watch: {},
  methods: {
    changeColor(val) {
      this.$emit('update:color', val);
    },
  },
};
</script>

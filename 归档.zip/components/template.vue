<style lang="scss" scoped>
</style>

<template>
  <div></div>
</template>

<script>
export default {
  components: {},
  computed: {},
  data() {
    return {};
  },
  methods: {},
  mounted() {},
};
</script>

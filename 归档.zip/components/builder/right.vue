<style lang="scss" scoped >
@import '@/assets/scss/editor.scss';

.slide {
  margin-left: 30px;
  width: 260px;
  position: fixed;
  right: 0;
  top: 60px;
  bottom: 0;
  box-sizing: border-box;
  border-left: 2px solid #e0e0e0;
  padding-left: 20px;
  z-index: 10;
  /deep/ {
    .el-input__inner {
      padding-top: 5px;
      padding-bottom: 5px;
    }
    .chosen {
      background: #efefef;
    }
  }
  .list {
    li {
      padding: 5px 10px;
      color: #666;
    }
  }
}

.item {
  font-size: 12px;
  .input {
    margin-bottom: 20px;
    padding-right: 10px;
  }
  .name {
    font-size: 16px;
  }
  .key {
    font-size: 14px;
    margin-bottom: 6px;
    color: #999;
  }
}

.tabs {
  height: 100%;
  /deep/ {
    .el-tabs__content {
      height: 100%;
      padding-right: 20px;
      padding-bottom: 100px;
      overflow-y: auto;
    }
  }
}
</style>

<template>
  <div class="slide">
    <el-tabs v-model="tab" class="tabs">
      <el-tab-pane label="视图" name="view">
        <draggable
          v-model="mods"
          :group="{ name: 'view' }"
          tag="ul"
          class="list"
          chosen-class="chosen"
        >
          <li
            class="pointer"
            v-for="item in mods"
            :key="item.uuid"
            @click="nodeclick(item)"
          >{{item.props.title || item.name}}</li>
        </draggable>
      </el-tab-pane>
      <el-tab-pane label="编辑" name="edit">
        <component :is="mod.com + 'Editor'" :mod="mod" v-if="mod"></component>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import draggable from 'vuedraggable';
import zinputEditor from '@/components/editor/zinputEditor';
import ztextEditor from '@/components/editor/ztextEditor';
import ztimeEditor from '@/components/editor/ztimeEditor';
import zdateEditor from '@/components/editor/zdateEditor';
import zdateTimeEditor from '@/components/editor/zdateTimeEditor';
import zdividerEditor from '@/components/editor/zdividerEditor';
import ztextareaEditor from '@/components/editor/ztextareaEditor';
import zselectEditor from '@/components/editor/zselectEditor';
import zimageEditor from '@/components/editor/zimageEditor';
import zcurrencyEditor from '@/components/editor/zcurrencyEditor';
import zuploaderImgEditor from '@/components/editor/zuploaderImgEditor';
import zuploaderFileEditor from '@/components/editor/zuploaderFileEditor';
import zradioEditor from '@/components/editor/zradioEditor';
import zcheckboxEditor from '@/components/editor/zcheckboxEditor';
import zsortEditor from '@/components/editor/zsortEditor';
import zrateEditor from '@/components/editor/zrateEditor';
import zswiperEditor from '@/components/editor/zswiperEditor';

export default {
  components: {
    draggable,
    zinputEditor,
    ztextEditor,
    ztimeEditor,
    zdateEditor,
    zdateTimeEditor,
    zdividerEditor,
    ztextareaEditor,
    zimageEditor,
    zselectEditor,
    zcurrencyEditor,
    zuploaderImgEditor,
    zradioEditor,
    zcheckboxEditor,
    zuploaderFileEditor,
    zsortEditor,
    zrateEditor,
    zswiperEditor,
  },
  watch: {},
  computed: {
    mods: {
      get() {
        let mods = this.$store.state.builder.mods;
        return mods;
      },
      set(value) {
        this.$store.commit('builder/mods', value);
      },
    },
    mod() {
      return this.$store.getters['builder/active'];
    },
    tab: {
      get() {
        return this.$store.state.builder.tab;
      },
      set(value) {
        this.$store.commit('builder/tab', value);
      },
    },
  },
  data() {
    return {};
  },
  mounted() {},
  methods: {
    nodeclick(item) {
      this.$store.commit('builder/activeid', item.uuid);
    },
  },
};
</script>


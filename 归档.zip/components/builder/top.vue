<style lang="scss" scoped>
.top {
  height: 60px;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 11;
  background: #000;
  color: #fff;
  .title {
    padding-left: 10px;
    line-height: 60px;
    font-size: 18px;
    font-weight: bold;
    .back {
      font-size: 20px;
    }
  }
  .time {
    font-weight: normal;
    font-size: 12px;
    color: #aaa;
    margin-left: 10px;
  }
  .actions {
    user-select: none;
    position: absolute;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
  }
  .group {
    padding: 0 15px;
    + .group {
      border-left: 1px solid rgba($color: #fff, $alpha: 0.4);
    }
  }
  .publish {
    cursor: pointer;
    font-size: 12px;
  }
  .iconfont {
    font-size: 24px;
    vertical-align: -4px;
    + .iconfont {
      margin-left: 15px;
    }

    cursor: pointer;
    &.disable {
      cursor: not-allowed;
      color: #666;
    }
  }

  .icon-erweima {
    font-size: 22px;
    margin-right: 5px;
  }
}
</style>

<template>
  <div class="top">
    <div class="title">
      <el-button
        type="primary"
        icon="el-icon-arrow-left"
        size="small"
        circle
        class="back"
        @click="backList"
      ></el-button>
      {{info.formName}}
      <span
        class="time"
      >最后保存：{{$momentFormat(info.saveConfigDate || info.createDate)}}</span>
    </div>
    <div class="actions">
      <span class="group">
        <i class="iconfont icon-zhixiangzuo disable" v-if="!past.length"></i>
        <i class="iconfont icon-zhixiangzuo" @click="back()" v-else></i>
        <i class="iconfont icon-zhixiangyou disable" v-if="!futrue.length"></i>
        <i class="iconfont icon-zhixiangyou" @click="forward()" v-else></i>
      </span>
      <span class="group">
        <span class="publish" @click="publish">
          <i class="iconfont icon-erweima"></i>发布
        </span>
      </span>
      <span class="group btns">
        <el-button type="primary" round size="mini" @click="save">保存</el-button>
        <el-button type="info" round size="small" @click="preview">预览</el-button>
      </span>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex';
export default {
  props: {
    info: '',
  },
  components: {},
  beforeRouteEnter(to, from, next) {
    next();
  },
  computed: {
    ...mapState({
      past: state => state.builder.past,
      futrue: state => state.builder.futrue,
    }),
  },
  data() {
    return {};
  },
  mounted() {},
  methods: {
    backList() {
      this.$router.push(`/project/${this.info.projectID}/form`);
    },
    save() {
      this.$emit('save');
    },
    back() {
      this.$store.commit('builder/back');
    },
    forward() {
      this.$store.commit('builder/forward');
    },
    preview() {
      this.$emit('preview');
    },
    publish() {
      this.$emit('publish');
    },
  },
};
</script>

<style lang="scss" scoped>
.slide {
  /deep/ {
    .el-carousel__mask,
    .el-cascader-menu,
    .el-cascader-menu__item.is-disabled:hover,
    .el-collapse-item__header,
    .el-collapse-item__wrap {
      background-color: transparent;
    }
  }
  width: 260px;
  height: 100%;
  background: #efefef;
  position: fixed;
  left: 0;
  top: 60px;
  bottom: 0;
  padding: 10px;
  box-sizing: border-box;
  overflow-y: auto;
  z-index: 10;
  .title {
    color: #999;
    font-size: 16px;
  }
  .list {
    padding: 10px;
    background: #fff;
    border-radius: 10px;
  }
  .item {
    width: 33.3%;
    float: left;
    padding: 0 10px 10px;
    text-align: center;
    font-size: 12px;
    height: 70px;
    cursor: pointer;
    border-radius: 5px;
    .icon {
      i {
        font-size: 20px;
      }
    }
    .name {
      line-height: 14px;
    }
    &:hover {
      background: #333;
      color: #ffd04b;
    }
  }
}
</style>

<template>
  <div class="slide">
    <el-collapse v-model="tab" class="pb60">
      <el-collapse-item name="show">
        <template slot="title">
          <span class="title">页面表现组件</span>
        </template>
        <draggable
          v-model="show"
          :group="{ name: 'mods', pull: 'clone', put: false }"
          :sort="false"
          chosen-class="chosen"
          :clone="clone"
          class="list clearfix"
        >
          <div class="item" v-for="(item,index) in show" :key="index">
            <div class="icon">
              <i class="iconfont" :class="item.icon"></i>
            </div>
            <div class="name line2">{{item.name}}</div>
          </div>
        </draggable>
      </el-collapse-item>
      <el-collapse-item name="base">
        <template slot="title">
          <span class="title">基础组件</span>
        </template>

        <draggable
          v-model="base"
          :group="{ name: 'mods', pull: 'clone', put: false }"
          :sort="false"
          chosen-class="chosen"
          :clone="clone"
          class="list clearfix"
        >
          <div class="item" v-for="(item,index) in base" :key="index">
            <div class="icon">
              <i class="iconfont" :class="item.icon"></i>
            </div>
            <div class="name line2">{{item.name}}</div>
          </div>
        </draggable>
      </el-collapse-item>
      <el-collapse-item name="userinfo">
        <template slot="title">
          <span class="title">用户信息组件</span>
        </template>
        <draggable
          v-model="userinfo"
          :group="{ name: 'mods', pull: 'clone', put: false }"
          :sort="false"
          chosen-class="chosen"
          :clone="clone"
          class="list clearfix"
        >
          <div class="item" v-for="(item,index) in userinfo" :key="index">
            <div class="icon">
              <i class="iconfont" :class="item.icon"></i>
            </div>
            <div class="name line2">{{item.name}}</div>
          </div>
        </draggable>
      </el-collapse-item>
    </el-collapse>
  </div>
</template>

<script>
import show from '@/assets/mods/show';
import base from '@/assets/mods/base';
import userinfo from '@/assets/mods/userinfo';
import draggable from 'vuedraggable';
import UUID from 'uuidjs';
export default {
  components: {
    draggable,
  },
  beforeRouteEnter(to, from, next) {
    next();
  },
  computed: {},
  data() {
    return {
      tab: ['show', 'base', 'userinfo'],
      show,
      base,
      userinfo,
    };
  },
  mounted() {},
  methods: {
    clone(data) {
      // this.$store.commit('builder/activeid', '');
      const uuid = UUID.generate();
      let obj = { ...data, uuid };
      console.log('create', obj);
      return obj;
    },
  },
};
</script>


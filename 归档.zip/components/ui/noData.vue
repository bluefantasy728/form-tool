<style lang="scss" scoped>
.text {
  text-align: center;
  font-size: 24px;
  color: #ccc;
}
</style>

<template>
  <div class="text">暂无数据</div>
</template>

<script>
export default {
  components: {},
  computed: {},
  data() {
    return {};
  },
  methods: {},
  mounted() {},
};
</script>

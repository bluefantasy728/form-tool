<style lang="scss" scoped>
.header {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background: #000000;
  border-bottom: solid 1px #e6e6e6;
  box-sizing: border-box;
  height: 61px;
  z-index: 10;
  .user {
    position: absolute;
    right: 30px;
    top: 50%;
    transform: translateY(-50%);
    color: #fff;
    cursor: pointer;
    padding: 10px 0;
  }
  .menu {
    width: 800px;
    margin: 0 auto;
  }
}
.btns .btn {
  cursor: pointer;
  padding: 0 10px;
}
</style>

<template>
  <div class="header">
    <el-menu
      :default-active="activeIndex"
      class="menu"
      mode="horizontal"
      router
      background-color="#000000"
      text-color="#fff"
      active-text-color="#ffd04b"
    >
      <el-menu-item index="/project">项目</el-menu-item>
      <el-menu-item index="/report">报表</el-menu-item>
      <el-menu-item index="/user">用户管理</el-menu-item>
      <el-menu-item index="/email" disabled>邮件</el-menu-item>
      <el-menu-item index="/note" disabled>短信</el-menu-item>
    </el-menu>
    <el-popover
      placement="bottom"
      trigger="click"
      popper-class="btns"
      :open-delay="0"
      transition="el-zoom-in-top"
    >
      <div slot="reference" class="user">{{user.username}}</div>
      <div class="btn" @click="logout">退出</div>
    </el-popover>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      activeIndex: '',
    };
  },
  created() {
    let arr = this.$route.path.split('/');
    if (arr.length > 2) {
      arr = arr.splice(0, 2);
    }
    this.activeIndex = arr.join('/');
  },
  watch: {
    '$route.path'() {
      let arr = this.$route.path.split('/');
      if (arr.length > 2) {
        arr.splice(0, 2);
      }
      this.activeIndex = arr.join('/');
    },
  },
  computed: {
    user() {
      return this.$store.state.user.user || {};
    },
  },
  methods: {
    async logout() {
      try {
        await this.$confirm('是否退出登录?');
        this.$cookie.remove('token');
        this.$router.replace('/login');
      } catch (err) {}
    },
  },
};
</script>

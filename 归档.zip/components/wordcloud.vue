<style lang="scss" scoped>
</style>

<template>
  <div>
    <v-chart :options="wordcloudOpt" @finished="onFinish"></v-chart>
  </div>
</template>

<script>
import 'echarts-wordcloud';
const wordcloudOpt = {
  tooltip: {
    show: true,
  },
  series: [
    {
      type: 'wordCloud',
      size: ['80%', '80%'],
      textRotation: [0, 45, 90, -45],
      textPadding: 0,
      autoSize: {
        enable: true,
        minSize: 14,
      },
      textStyle: {
        normal: {
          color: function() {
            return (
              'rgb(' +
              [
                Math.round(Math.random() * 160),
                Math.round(Math.random() * 160),
                Math.round(Math.random() * 160),
              ].join(',') +
              ')'
            );
          },
        },
      },
      data: [],
    },
  ],
  animation: false,
};
export default {
  props: ['xdata'],
  components: {},
  computed: {},
  watch: {
    xdata: {
      handler(newValue, oldValue) {
        this.getOpt();
      },
    },
  },
  data() {
    return {
      wordcloudOpt,
    };
  },
  methods: {
    onFinish() {
      this.$emit('finished');
    },
    getOpt() {
      this.wordcloudOpt.series[0].data = this.xdata;
    },
  },
  mounted() {
    this.getOpt();
  },
};
</script>

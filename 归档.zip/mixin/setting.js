export default {
  methods: {
    async getData() {
      try {
        let res = await this.$axios.$get(`/report/${this.reportId}`);
        this.details = res;
      } catch (err) {}
    },
    async putData() {
      try {
        let res = await this.$axios.$put(`/report`, {
          reportColumnParam: this.details.reportColumnParam,
          reportConditionParam: this.details.reportConditionParam,
          reportDescription: this.details.reportDescription,
          reportId: this.details.id,
          reportName: this.details.reportName
        });
        this.$message({
          message: '保存成功',
          type: 'success'
        });
        this.getData();
      } catch (err) {}
    },
  },
}

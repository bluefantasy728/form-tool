import _ from 'lodash';
import arrayInput from '@/components/input/arrayInput';
import colorInput from '@/components/input/colorInput';

export default {
  props: ['mod'],
  components: {
    arrayInput,
    colorInput,
  },
  computed: {},
  watch: {
    mod(value) {
      if (_.isEqual(value.props, this.store)) {
        return;
      }
      this.addStore();
    },
    store: {
      handler(value) {
        this.$store.commit('builder/update', value);
      },
      deep: true,
    },
  },
  data() {
    return {
      store: {},
    };
  },
  methods: {
    positive(item, key) {
      let value = item.target.value;
      value = value.replace(/[^\.\d]/g, '');
      value = value.replace('-', '');
      value = value.replace('.', '');
      if (value) {
        _.set(this, key, Number(value));
      } else {
        _.set(this, key, value);
      }
    },
    addStore() {
      this.store = _.cloneDeep(this.mod.props);
    },
  },
  mounted() {
    this.addStore();
  },
};

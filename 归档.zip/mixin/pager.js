export default {
  watchQuery: true,
  beforeRouteEnter(to, from, next) {
    next();
  },
  data() {
    return {
      total: 1,
    };
  },
  computed: {
    pageNo() {
      return this.$store.state.pager.pageNo;
    },
    pageSize() {
      return this.$store.state.pager.pageSize;
    },
  },
  methods: {
    currentChange(page) {
      this.pageChange(page, this.pageSize);
    },
    sizeChange(pageSize) {
      this.pageChange(this.pageNo, pageSize);
    },
    pageChange(pageNo, pageSize) {
      this.$router.push({
        path: this.$route.path,
        query: {
          ...this.$route.query,
          pageNo,
          pageSize,
        },
      });
    },
  },
};

# api

> http://192.168.1.248:8098/swagger-ui.html

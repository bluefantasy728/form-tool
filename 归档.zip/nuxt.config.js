const pkg = require('./package');
module.exports = {
  env: {
    baseUrl: 'http://192.168.1.248:8098',
  },
  vue: {
    //runtimeCompiler: true,
  },
  mode: 'universal',
  loading: {
    color: '#ffd04b',
  },
  server: {
    port: 3002,
    host: '0.0.0.0',
  },
  head: {
    title: pkg.name,
    meta: [{
        charset: 'utf-8',
      },
      {
        name: 'viewport',
        content: 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0',
      },
      {
        hid: 'description',
        name: 'description',
        content: pkg.description,
      },
    ],
    link: [{
      rel: 'icon',
      type: 'image/x-icon',
      href: '/favicon.ico',
    }, ],
  },
  css: [
    'normalize.css',
    'swiper/dist/css/swiper.css',
    '~/static/000000/index.css',
    '~/static/iconfont/iconfont.css',
  ],
  plugins: [
    '@/plugins/element-ui',
    '@/plugins/axios.js',
    '@/plugins/cookie.js',
    '@/plugins/moment.js',
    {
      src: '@/plugins/vue-echarts.js',
      ssr: false,
    },
    {
      src: 'plugins/swiper.js',
      ssr: false,
    },
  ],
  modules: ['@nuxtjs/axios'],
  build: {
    transpile: [/^element-ui/],
    extractCSS: true,
    optimizeCSS: true,
    extend(config) {
      config.resolve.alias['vue'] = 'vue/dist/vue.common';
    },
  },
  router: {
    base: '/form_tools',
    extendRoutes(routes) {
      routes.forEach(route => {});
    },
    middleware: ['auth', 'redirect'],
    scrollBehavior: (to, from, savedPosition) => {
      if (to.hash) {
        return {
          selector: to.hash,
        };
      } else {
        return {
          x: 0,
          y: 0,
        };
      }
    },
  },
};

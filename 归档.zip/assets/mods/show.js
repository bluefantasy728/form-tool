let mods = [
  {
    icon: 'icon-wenzi',
    name: '文字',
    com: 'ztext',
    editable: false,
    props: {
      title: '文字',
      desc: '',
      align: 'left',
      color: '#000',
      fontSize: 16,
      fontWeight: 400,
      fontStyle: 'normal',
    },
  },

  {
    icon: 'icon-tu',
    name: '图片',
    com: 'zimage',
    editable: false,
    props: {
      title: '',
      desc: '',
      align: 'center',
      isWholeRow: false,
      requireUrl: false,
      isMultiple: false,
      imgUrl: '',
      url: '',
    },
  },

  {
    icon: 'icon-fengexian',
    name: '分割线',
    com: 'zdivider',
    editable: false,
    props: {
      title: '',
      desc: '',
      // align: 'left',
      color: '#ccc',
      width: 1,
      type: 'dashed',
    },
  },
  {
    icon: 'icon-fengexian',
    name: '图片轮播图',
    com: 'zswiper',
    editable: false,
    props: {
      title: '图片轮播图',
      desc: '图片轮播图图片轮播图',
      required: false,
      hide: false,
      pics: [
        {
          picUrl:
            'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2831960734,63197009&fm=26&gp=0.jpg',
          linkUrl: 'https://www.baidu.com',
        },
        {
          picUrl:
            'https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=2106538132,4174177087&fm=26&gp=0.jpg',
          linkUrl: 'https://www.baidu.com',
        },
      ],
    },
  },
];
export default mods;

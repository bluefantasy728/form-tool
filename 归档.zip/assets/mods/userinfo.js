let mods = [
  {
    icon: 'icon-danhangshurukuang',
    name: '输入框',
    com: 'zinput',
    editable: true,
    props: {
      title: '',
      desc: '',
      placeholder: '',
      minlength: null,
      maxlength: null,
      rule: '',
      ruleDiy: '',
      width: '100%',
      required: false,
      noRepeat: false,
      password: false,
      hide: false,
    },
  },
];
export default mods;

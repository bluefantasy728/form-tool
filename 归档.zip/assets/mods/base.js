let mods = [{
    icon: 'icon-danhangshurukuang',
    name: '文本输入',
    com: 'zinput',
    editable: true,
    props: {
      title: '文本输入',
      desc: '',
      placeholder: '',
      minlength: null,
      maxlength: null,
      rule: '',
      ruleDiy: '',
      width: '100%',
      required: false,
      noRepeat: false,
      password: false,
      hide: false,
      keyword: false
    },
  },
  {
    icon: 'icon-duohangshurukuang',
    name: '多行文本输入',
    com: 'ztextarea',
    editable: true,
    props: {
      title: '多行文本输入',
      desc: '',
      placeholder: '',
      width: '100%',
      required: false,
      password: false,
      hide: false,
      rows: 3,
      keyword: false
    },
  },
  {
    icon: 'icon-xialakuangbiaodan',
    name: '下拉选择',
    com: 'zselect',
    editable: true,
    props: {
      title: '下拉选择',
      desc: '',
      placeholder: '请选择',
      options: [{
          label: '选项1',
          selected: true
        },
        {
          label: '选项2',
          selected: false
        },
      ],
      width: '100%',
    },
  },
  {
    icon: 'icon-danxuan',
    name: '单选',
    com: 'zradio',
    editable: true,
    props: {
      title: '单选',
      desc: '',
      options: [{
          label: '选项1',
          selected: false
        },
        {
          label: '选项2',
          selected: false
        },
      ],
      other: false,
    },
  },
  {
    icon: 'icon-xuanze',
    name: '多选',
    com: 'zcheckbox',
    editable: true,
    props: {
      title: '多选',
      desc: '',
      options: [{
          label: '选项1',
          selected: false
        },
        {
          label: '选项2',
          selected: false
        },
      ],
      other: false,
      min: 0,
      max: 3,
    },
  },
  {
    icon: 'icon-riqi',
    name: '日期选择',
    com: 'zdate',
    editable: true,
    props: {
      title: '日期选择',
      desc: '',
      placeholder: '',
      required: false,
      noRepeat: false,
      hide: false,
      value: '',
      valueDiy: '',
      startTime: '',
      endTime: '',
      startDiy: '',
      endDiy: '',
    },
  },

  {
    icon: 'icon-date-1',
    name: '时间选择',
    com: 'ztime',
    editable: true,
    props: {
      title: '时间选择',
      desc: '',
      placeholder: '',
      required: false,
      noRepeat: false,
      hide: false,
      value: '',
      valueDiy: '',
      startTime: '00:00:00',
      endTime: '23:59:59',
    },
  },

  {
    icon: 'icon-shijianriqi',
    name: '日期时间选择',
    com: 'zdateTime',
    editable: true,
    props: {
      title: '日期时间选择',
      desc: '',
      placeholder: '',
      required: false,
      noRepeat: false,
      hide: false,
      value: '',
      valueDiy: '',
      startTime: '',
      endTime: '',
      startDiy: '',
      endDiy: '',
    },
  },
  {
    icon: 'icon-ziyuan',
    name: '货币',
    com: 'zcurrency',
    editable: true,
    props: {
      title: '货币',
      desc: '',
      placeholder: '',
      unit: 'RMB',
      required: false,
      hide: false,
      max: null,
      min: null,
    },
  },
  {
    icon: 'icon-weimingming-',
    name: '图片上传',
    com: 'zuploaderImg',
    editable: true,
    props: {
      title: '图片上传',
      desc: '',
      required: false,
      isMultiple: false,
      hide: false,
      limitSize: 5000,
      limitQty: 1,
      acceptImgFormat: '',
    },
  },
  {
    icon: 'icon-shangchuanfujian',
    name: '附件上传',
    com: 'zuploaderFile',
    editable: true,
    props: {
      title: '附件上传',
      desc: '',
      required: false,
      hide: false,
      limitSize: 5000,
      limitQty: 1,
      acceptFileFormat: '',
    },
  },
  {
    icon: 'icon-paixu',
    name: '排序',
    com: 'zsort',
    editable: true,
    props: {
      title: '排序',
      desc: '请将右边的选项拖动到左边进行排序',
      required: false,
      hide: false,
      options: [{
          label: '选项1',
          selected: false
        },
        {
          label: '选项2',
          selected: false
        },
        {
          label: '选项3',
          selected: false
        },
        {
          label: '选项4',
          selected: false
        },
        {
          label: '选项5',
          selected: false
        },
      ],
      min: 1,
      max: 5,
    },
  },
  {
    icon: 'icon-rate',
    name: '评分',
    com: 'zrate',
    editable: true,
    props: {
      title: '评分',
      desc: '',
      required: false,
      showText: true,
      icon: 'el-icon-star-on',
      hide: false,
      fontSize: 18,
      max: 5,
      default: 0,
      texts: ['极差', '失望', '一般', '满意', '惊喜'],
    },
  },
];
export default mods;

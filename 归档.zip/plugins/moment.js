import moment from 'miment';

export default ({
  app
}, inject) => {
  inject('moment', moment);
  inject('momentFormat', (date, format) => {
    if (format) {
      return moment(date).format(format);
    }
    return moment(date).format('YYYY-MM-DD hh:mm:ss');
  });
};

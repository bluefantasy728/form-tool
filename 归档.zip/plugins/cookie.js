// https://github.com/js-cookie/js-cookie

import Vue from 'vue';
import Cookies from 'js-cookie';

Cookies.defaults = {
  expires: 1,
};

Vue.prototype.$cookie = Cookies;

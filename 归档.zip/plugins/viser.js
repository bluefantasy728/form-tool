import Vue from 'vue'
import viser from 'viser-vue'
export default () => {
  Vue.use(viser);
};

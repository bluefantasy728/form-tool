// See https://github.com/nuxt-community/axios-module#options

import Cookies from 'js-cookie';
import cookie from 'cookie';
import { Message, Loading } from 'element-ui/lib/element-ui.common';

export default function({ app, route, store, $axios, redirect }) {
  let loadingInstance = null;
  $axios.onRequest(config => {
    if (process.client) {
      loadingInstance = Loading.service({
        fullscreen: true,
        text: 'loading...',
      });
    }

    //baseURL
    config.baseURL = process.env.baseUrl;

    //cookie
    let cookies = {};
    if (process.server) {
      cookies = cookie.parse(app.context.req.headers.cookie || '');
    } else {
      cookies = Cookies.getJSON();
    }

    //分页处理
    if (!config.params) {
      config.params = {};
    }
    let pageNo = app.context.query.pageNo || 1;
    let pageSize = app.context.query.pageSize || store.state.pager.pageSize;
    store.commit('pager/pageNo', pageNo - 0);
    store.commit('pager/pageSize', pageSize - 0);
    config.params.pageNum = pageNo;
    config.params.pageSize = pageSize;

    //token
    if (cookies.token) {
      config.headers.common['token'] = cookies.token;
    }
    return config;
  });

  $axios.onResponse(res => {
    if (loadingInstance) {
      loadingInstance.close();
    }
    return res.data;
  });

  $axios.onError(error => {
    if (loadingInstance) {
      loadingInstance.close();
    }
    const code = parseInt(error.response && error.response.status);
    if (process.client) {
      Message({
        message: error.response.data.message,
        type: 'error',
      });
      return Promise.reject(error.response.data);
    }

    if (code === 401) {
      redirect(`/login`);
    }
  });
}

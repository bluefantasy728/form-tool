import Vue from 'vue'
import echarts from 'vue-echarts'
import wchart from '@/components/wordcloud'
export default () => {
  Vue.component('v-chart', echarts);
  Vue.component('wchart', wchart)
};

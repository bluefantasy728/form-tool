<template>
  <div>
    <nuxt/>
  </div>
</template>

<style lang="scss">
@import '@/assets/scss/global.scss';
</style>

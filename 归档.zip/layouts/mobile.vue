<template>
  <div>
    <nuxt/>
  </div>
</template>

<style lang="scss">
@import '@/assets/scss/global.scss';
</style>

<script>
export default {
  head: {
    meta: [
      {
        hid: 'viewport',
        name: 'viewport',
        content: 'target-densitydpi=device-dpi,width=375,user-scalable=no',
      },
    ],
    bodyAttrs: {
      class: 'mobile',
    },
  },
};
</script>

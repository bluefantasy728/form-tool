import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _867e28b6 = () => interopDefault(import('../pages/builder.vue' /* webpackChunkName: "pages/builder" */))
const _70fd68f3 = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _40514fba = () => interopDefault(import('../pages/project.vue' /* webpackChunkName: "pages/project" */))
const _53880f34 = () => interopDefault(import('../pages/project/index.vue' /* webpackChunkName: "pages/project/index" */))
const _ea4734d6 = () => interopDefault(import('../pages/project/_projectId/form/index.vue' /* webpackChunkName: "pages/project/_projectId/form/index" */))
const _92414fa2 = () => interopDefault(import('../pages/project/_projectId/form/_formId/detail.vue' /* webpackChunkName: "pages/project/_projectId/form/_formId/detail" */))
const _cad6983c = () => interopDefault(import('../pages/project/_projectId/form/_formId/setting.vue' /* webpackChunkName: "pages/project/_projectId/form/_formId/setting" */))
const _9b369a0e = () => interopDefault(import('../pages/project/_projectId/form/_formId/source.vue' /* webpackChunkName: "pages/project/_projectId/form/_formId/source" */))
const _7fe92709 = () => interopDefault(import('../pages/register.vue' /* webpackChunkName: "pages/register" */))
const _e6cdcecc = () => interopDefault(import('../pages/report.vue' /* webpackChunkName: "pages/report" */))
const _71b3439d = () => interopDefault(import('../pages/report/index.vue' /* webpackChunkName: "pages/report/index" */))
const _b812ec28 = () => interopDefault(import('../pages/report/_formId/index.vue' /* webpackChunkName: "pages/report/_formId/index" */))
const _635310d3 = () => interopDefault(import('../pages/report/_formId/_reportId/analysis.vue' /* webpackChunkName: "pages/report/_formId/_reportId/analysis" */))
const _6a566d16 = () => interopDefault(import('../pages/report/_formId/_reportId/analysis/index.vue' /* webpackChunkName: "pages/report/_formId/_reportId/analysis/index" */))
const _d70da1ee = () => interopDefault(import('../pages/report/_formId/_reportId/analysis/result.vue' /* webpackChunkName: "pages/report/_formId/_reportId/analysis/result" */))
const _341fff88 = () => interopDefault(import('../pages/report/_formId/_reportId/detail.vue' /* webpackChunkName: "pages/report/_formId/_reportId/detail" */))
const _752e10ae = () => interopDefault(import('../pages/report/_formId/_reportId/setting.vue' /* webpackChunkName: "pages/report/_formId/_reportId/setting" */))
const _3a5d5b6c = () => interopDefault(import('../pages/report/_formId/_reportId/setting/index.vue' /* webpackChunkName: "pages/report/_formId/_reportId/setting/index" */))
const _edc1f672 = () => interopDefault(import('../pages/report/_formId/_reportId/setting/custom.vue' /* webpackChunkName: "pages/report/_formId/_reportId/setting/custom" */))
const _220782f4 = () => interopDefault(import('../pages/report/_formId/_reportId/setting/list.vue' /* webpackChunkName: "pages/report/_formId/_reportId/setting/list" */))
const _501833d9 = () => interopDefault(import('../pages/reset.vue' /* webpackChunkName: "pages/reset" */))
const _1808e731 = () => interopDefault(import('../pages/user.vue' /* webpackChunkName: "pages/user" */))
const _3544f618 = () => interopDefault(import('../pages/user/index.vue' /* webpackChunkName: "pages/user/index" */))
const _7385e178 = () => interopDefault(import('../pages/user/data.vue' /* webpackChunkName: "pages/user/data" */))
const _1d740bd4 = () => interopDefault(import('../pages/user/label.vue' /* webpackChunkName: "pages/user/label" */))
const _38b849bc = () => interopDefault(import('../pages/user/newlabel.vue' /* webpackChunkName: "pages/user/newlabel" */))
const _605710ca = () => interopDefault(import('../pages/user/_userId/index.vue' /* webpackChunkName: "pages/user/_userId/index" */))
const _42de1809 = () => interopDefault(import('../pages/user/_userId/detail.vue' /* webpackChunkName: "pages/user/_userId/detail" */))
const _47cd6756 = () => interopDefault(import('../pages/form/_id.vue' /* webpackChunkName: "pages/form/_id" */))
const _e57d5406 = () => interopDefault(import('../pages/preview/_id.vue' /* webpackChunkName: "pages/preview/_id" */))

Vue.use(Router)

const scrollBehavior = (to, from, savedPosition) => {
      if (to.hash) {
        return {
          selector: to.hash,
        };
      } else {
        return {
          x: 0,
          y: 0,
        };
      }
    }

export function createRouter() {
  return new Router({
    mode: 'history',
    base: decodeURI('/form_tools/'),
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/builder",
      component: _867e28b6,
      name: "builder"
    }, {
      path: "/login",
      component: _70fd68f3,
      name: "login"
    }, {
      path: "/project",
      component: _40514fba,
      children: [{
        path: "",
        component: _53880f34,
        name: "project"
      }, {
        path: ":projectId/form",
        component: _ea4734d6,
        name: "project-projectId-form"
      }, {
        path: ":projectId/form/:formId/detail",
        component: _92414fa2,
        name: "project-projectId-form-formId-detail"
      }, {
        path: ":projectId/form/:formId/setting",
        component: _cad6983c,
        name: "project-projectId-form-formId-setting"
      }, {
        path: ":projectId/form/:formId/source",
        component: _9b369a0e,
        name: "project-projectId-form-formId-source"
      }]
    }, {
      path: "/register",
      component: _7fe92709,
      name: "register"
    }, {
      path: "/report",
      component: _e6cdcecc,
      children: [{
        path: "",
        component: _71b3439d,
        name: "report"
      }, {
        path: ":formId",
        component: _b812ec28,
        name: "report-formId"
      }, {
        path: ":formId/:reportId/analysis",
        component: _635310d3,
        children: [{
          path: "",
          component: _6a566d16,
          name: "report-formId-reportId-analysis"
        }, {
          path: "result",
          component: _d70da1ee,
          name: "report-formId-reportId-analysis-result"
        }]
      }, {
        path: ":formId/:reportId/detail",
        component: _341fff88,
        name: "report-formId-reportId-detail"
      }, {
        path: ":formId/:reportId/setting",
        component: _752e10ae,
        children: [{
          path: "",
          component: _3a5d5b6c,
          name: "report-formId-reportId-setting"
        }, {
          path: "custom",
          component: _edc1f672,
          name: "report-formId-reportId-setting-custom"
        }, {
          path: "list",
          component: _220782f4,
          name: "report-formId-reportId-setting-list"
        }]
      }]
    }, {
      path: "/reset",
      component: _501833d9,
      name: "reset"
    }, {
      path: "/user",
      component: _1808e731,
      children: [{
        path: "",
        component: _3544f618,
        name: "user"
      }, {
        path: "data",
        component: _7385e178,
        name: "user-data"
      }, {
        path: "label",
        component: _1d740bd4,
        name: "user-label"
      }, {
        path: "newlabel",
        component: _38b849bc,
        name: "user-newlabel"
      }, {
        path: ":userId",
        component: _605710ca,
        name: "user-userId"
      }, {
        path: ":userId/detail",
        component: _42de1809,
        name: "user-userId-detail"
      }]
    }, {
      path: "/form/:id?",
      component: _47cd6756,
      name: "form-id"
    }, {
      path: "/preview/:id?",
      component: _e57d5406,
      name: "preview-id"
    }],

    fallback: false
  })
}
